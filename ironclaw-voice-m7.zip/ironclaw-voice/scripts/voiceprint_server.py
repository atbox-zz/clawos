#!/usr/bin/env python3
"""
scripts/voiceprint_server.py
IronClaw 聲紋驗證服務 — ECAPA-TDNN (SpeechBrain)

端點：
  POST /embed   → 提取聲紋嵌入向量
  POST /verify  → 比對兩段聲音
  GET  /health  → 健康檢查

安裝：
  pip install speechbrain torch torchaudio fastapi uvicorn
"""

import base64
import io
import time
import tempfile
import os
from typing import Optional

import torch
import torchaudio
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="IronClaw Voiceprint Server", version="1.0.0")

# ─── 模型載入 ─────────────────────────────────────────────────────────────────

print("⏳ 載入 ECAPA-TDNN 模型 (SpeechBrain)...")
try:
    from speechbrain.inference.speaker import EncoderClassifier
    CLASSIFIER = EncoderClassifier.from_hparams(
        source="speechbrain/spkrec-ecapa-voxceleb",
        savedir="/tmp/speechbrain-ecapa",
        run_opts={"device": "cuda" if torch.cuda.is_available() else "cpu"},
    )
    print(f"✅ ECAPA-TDNN 載入完成，使用: {'GPU' if torch.cuda.is_available() else 'CPU'}")
    MODEL_LOADED = True
except Exception as e:
    print(f"⚠️  ECAPA-TDNN 載入失敗: {e}")
    print("   使用 Mock 模式（嵌入向量為隨機）")
    CLASSIFIER = None
    MODEL_LOADED = False

TARGET_SR = 16000  # ECAPA-TDNN 要求 16kHz

# ─── 工具函式 ─────────────────────────────────────────────────────────────────

def decode_audio(audio_b64: str) -> tuple[torch.Tensor, float]:
    """解碼 base64 WAV，回傳 (waveform[1,T], rms)"""
    wav_bytes = base64.b64decode(audio_b64)
    buf = io.BytesIO(wav_bytes)
    waveform, sr = torchaudio.load(buf)

    # 轉 mono
    if waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)

    # 重採樣到 16kHz
    if sr != TARGET_SR:
        resampler = torchaudio.transforms.Resample(orig_freq=sr, new_freq=TARGET_SR)
        waveform = resampler(waveform)

    rms = float(waveform.pow(2).mean().sqrt().item())
    return waveform, rms


def is_speech(waveform: torch.Tensor, rms_threshold: float = 0.005) -> bool:
    """簡易靜默偵測"""
    rms = float(waveform.pow(2).mean().sqrt().item())
    return rms > rms_threshold


def extract_embedding(waveform: torch.Tensor) -> list[float]:
    """提取 ECAPA-TDNN 192 維聲紋嵌入"""
    if CLASSIFIER is None:
        # Mock 模式：回傳可重現的假向量（用 RMS 做 seed）
        rms = float(waveform.pow(2).mean().sqrt().item())
        np.random.seed(int(rms * 1e6) % (2**31))
        emb = np.random.randn(192).astype(np.float32)
        emb = emb / np.linalg.norm(emb)
        return emb.tolist()

    with torch.no_grad():
        embedding = CLASSIFIER.encode_batch(waveform)
        # shape: [1, 1, 192] → [192]
        emb = embedding.squeeze().cpu().numpy()
        # L2 正規化
        emb = emb / (np.linalg.norm(emb) + 1e-8)
    return emb.tolist()


def cosine_similarity(a: list[float], b: list[float]) -> float:
    a_np = np.array(a, dtype=np.float32)
    b_np = np.array(b, dtype=np.float32)
    dot = np.dot(a_np, b_np)
    norm = np.linalg.norm(a_np) * np.linalg.norm(b_np)
    if norm < 1e-8:
        return 0.0
    return float(np.clip(dot / norm, -1.0, 1.0))

# ─── API 模型 ─────────────────────────────────────────────────────────────────

class EmbedRequest(BaseModel):
    audio_b64: str

class EmbedResponse(BaseModel):
    embedding: list[float]
    is_speech: bool
    rms: float
    latency_ms: float

class VerifyRequest(BaseModel):
    audio_b64: str
    template_embedding: list[float]

class VerifyResponse(BaseModel):
    score: float
    is_speech: bool
    rms: float
    latency_ms: float

# ─── 端點 ─────────────────────────────────────────────────────────────────────

@app.post("/embed", response_model=EmbedResponse)
async def embed(req: EmbedRequest):
    """提取聲紋嵌入向量（登錄用）"""
    t0 = time.time()
    try:
        waveform, rms = decode_audio(req.audio_b64)
        has_speech = is_speech(waveform)
        embedding = extract_embedding(waveform) if has_speech else [0.0] * 192
        latency_ms = (time.time() - t0) * 1000

        return EmbedResponse(
            embedding=embedding,
            is_speech=has_speech,
            rms=rms,
            latency_ms=latency_ms,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"嵌入提取失敗: {e}")


@app.post("/verify", response_model=VerifyResponse)
async def verify(req: VerifyRequest):
    """比對聲音與模板（驗證用）"""
    t0 = time.time()
    try:
        waveform, rms = decode_audio(req.audio_b64)
        has_speech = is_speech(waveform)

        if not has_speech:
            return VerifyResponse(score=0.0, is_speech=False, rms=rms,
                                  latency_ms=(time.time()-t0)*1000)

        embedding = extract_embedding(waveform)
        score = cosine_similarity(embedding, req.template_embedding)
        latency_ms = (time.time() - t0) * 1000

        print(f"[verify] score={score:.4f} rms={rms:.4f} latency={latency_ms:.0f}ms"
              f" model={'ecapa' if MODEL_LOADED else 'mock'}")

        return VerifyResponse(
            score=score,
            is_speech=True,
            rms=rms,
            latency_ms=latency_ms,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"聲紋比對失敗: {e}")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "model": "ECAPA-TDNN" if MODEL_LOADED else "mock",
        "device": "cuda" if torch.cuda.is_available() else "cpu",
    }


if __name__ == "__main__":
    import uvicorn
    print("🎙  IronClaw Voiceprint Server 啟動中...")
    uvicorn.run(app, host="127.0.0.1", port=8767, log_level="info")
