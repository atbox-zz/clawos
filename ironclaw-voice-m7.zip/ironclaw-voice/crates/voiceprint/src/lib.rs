//! voiceprint — ECAPA-TDNN 聲紋驗證模組
//!
//! 功能：
//!   - 聲紋登錄（enrollment）：錄 3 段語音，建立使用者聲紋模板
//!   - 聲紋驗證（verification）：比對即時語音與模板
//!   - Challenge-Response 流程：高風險操作時觸發，要求說指定口令
//!   - 反仿冒（anti-spoofing）：簡易靜默偵測
//!
//! 架構：
//!   Rust（狀態機 + 流程控制）
//!     ↕ HTTP
//!   Python（ECAPA-TDNN 推理，SpeechBrain）

use anyhow::{Context, Result};
use base64::{Engine, engine::general_purpose::STANDARD as BASE64};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use tokio::sync::{mpsc, oneshot};
use tracing::{debug, error, info, warn};
use voice_capture::AudioChunk;

// ─── 公開型別 ─────────────────────────────────────────────────────────────────

/// 聲紋驗證結果
#[derive(Debug, Clone)]
pub enum VerifyResult {
    /// 通過（相似度 >= 門檻）
    Passed { score: f32, latency_ms: u64 },
    /// 拒絕（相似度 < 門檻）
    Rejected { score: f32, attempts: u32 },
    /// 超過嘗試次數上限
    MaxAttemptsReached,
    /// 靜默/假聲音 (anti-spoof)
    Spoofing,
}

/// Challenge 任務：要求使用者說這句話來確認身份
#[derive(Debug, Clone)]
pub struct VoiceChallenge {
    pub operation: String,       // 即將執行的操作名稱（台語）
    pub passphrase: String,      // 要求使用者複誦的口令（台語）
    pub max_attempts: u32,
}

impl VoiceChallenge {
    /// 依操作類型產生對應的台語確認口令
    pub fn for_operation(op: &str, detail: &str) -> Self {
        let (operation, passphrase) = match op {
            "lock_system" => (
                format!("鎖定系統：{}", detail),
                "我確認，共鐵爪鎖定系統".to_string(),
            ),
            "delete_firewall_rule" => (
                format!("刪除防火牆規則：{}", detail),
                "我確認，共這條規則刪掉".to_string(),
            ),
            "kernel_modify" => (
                format!("修改核心設定：{}", detail),
                "我確認，允准修改核心".to_string(),
            ),
            _ => (
                format!("執行高風險操作：{}", detail),
                "我確認，允准執行".to_string(),
            ),
        };
        Self { operation, passphrase, max_attempts: 3 }
    }
}

/// 登錄狀態
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EnrollmentRecord {
    pub user_id: String,
    pub enrolled_at: DateTime<Utc>,
    pub sample_count: u32,
    /// 聲紋嵌入向量（192 維，ECAPA-TDNN 輸出）
    pub embedding: Vec<f32>,
    pub embedding_path: PathBuf, // 也存到磁碟
}

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Deserialize)]
pub struct VoiceprintConfig {
    /// ECAPA-TDNN 服務端點
    #[serde(default = "default_vp_endpoint")]
    pub endpoint: String,

    /// 驗證通過門檻（cosine similarity，0.0~1.0）
    #[serde(default = "default_threshold")]
    pub threshold: f32,

    /// 登錄所需樣本數
    #[serde(default = "default_enroll_samples")]
    pub enroll_samples: u32,

    /// 最多嘗試次數
    #[serde(default = "default_max_attempts")]
    pub max_attempts: u32,

    /// 聲紋資料存放目錄
    #[serde(default = "default_store_dir")]
    pub store_dir: String,

    /// 啟用 anti-spoof 偵測
    #[serde(default = "default_anti_spoof")]
    pub anti_spoof: bool,

    /// 靜默 RMS 門檻（太低視為靜默/假聲音）
    #[serde(default = "default_liveness_rms")]
    pub liveness_rms: f32,
}

fn default_vp_endpoint()    -> String { "http://127.0.0.1:8767".to_string() }
fn default_threshold()      -> f32    { 0.85 }
fn default_enroll_samples() -> u32    { 3 }
fn default_max_attempts()   -> u32    { 3 }
fn default_store_dir()      -> String { "/var/lib/ironclaw/voiceprints".to_string() }
fn default_anti_spoof()     -> bool   { true }
fn default_liveness_rms()   -> f32    { 0.01 }

impl Default for VoiceprintConfig {
    fn default() -> Self {
        Self {
            endpoint: default_vp_endpoint(),
            threshold: default_threshold(),
            enroll_samples: default_enroll_samples(),
            max_attempts: default_max_attempts(),
            store_dir: default_store_dir(),
            anti_spoof: default_anti_spoof(),
            liveness_rms: default_liveness_rms(),
        }
    }
}

// ─── ECAPA-TDNN 客戶端 ────────────────────────────────────────────────────────

struct EcapaClient {
    http: reqwest::Client,
    endpoint: String,
}

#[derive(Serialize)]
struct EmbedRequest<'a> {
    audio_b64: &'a str,
}

#[derive(Deserialize)]
struct EmbedResponse {
    embedding: Vec<f32>,   // 192 維
    is_speech: bool,       // anti-spoof: 是否真的有說話
    rms: f32,
}

#[derive(Serialize)]
struct VerifyRequest<'a> {
    audio_b64: &'a str,
    template_embedding: &'a [f32],
}

#[derive(Deserialize)]
struct VerifyResponse {
    score: f32,            // cosine similarity
    is_speech: bool,
    rms: f32,
    latency_ms: u64,
}

impl EcapaClient {
    fn new(endpoint: &str) -> Result<Self> {
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(15))
            .build()?;
        Ok(Self { http, endpoint: endpoint.to_string() })
    }

    /// 提取聲紋嵌入向量
    async fn embed(&self, chunk: &AudioChunk) -> Result<EmbedResponse> {
        let wav = chunk.to_wav_bytes()?;
        let audio_b64 = BASE64.encode(&wav);

        self.http
            .post(format!("{}/embed", self.endpoint))
            .json(&EmbedRequest { audio_b64: &audio_b64 })
            .send().await
            .context("ECAPA embed 請求失敗")?
            .json().await
            .context("ECAPA embed 回應解析失敗")
    }

    /// 直接比對：送音訊 + 模板，回傳分數
    async fn verify(&self, chunk: &AudioChunk, template: &[f32]) -> Result<VerifyResponse> {
        let wav = chunk.to_wav_bytes()?;
        let audio_b64 = BASE64.encode(&wav);

        self.http
            .post(format!("{}/verify", self.endpoint))
            .json(&VerifyRequest { audio_b64: &audio_b64, template_embedding: template })
            .send().await
            .context("ECAPA verify 請求失敗")?
            .json().await
            .context("ECAPA verify 回應解析失敗")
    }
}

// ─── 聲紋儲存 ─────────────────────────────────────────────────────────────────

fn enrollment_path(store_dir: &str, user_id: &str) -> PathBuf {
    Path::new(store_dir).join(format!("{}.vp.json", user_id))
}

async fn load_enrollment(store_dir: &str, user_id: &str) -> Option<EnrollmentRecord> {
    let path = enrollment_path(store_dir, user_id);
    let data = tokio::fs::read_to_string(&path).await.ok()?;
    serde_json::from_str(&data).ok()
}

async fn save_enrollment(record: &EnrollmentRecord, store_dir: &str) -> Result<()> {
    tokio::fs::create_dir_all(store_dir).await
        .context("無法建立聲紋存放目錄")?;
    let path = enrollment_path(store_dir, &record.user_id);
    let data = serde_json::to_string_pretty(record)?;
    tokio::fs::write(&path, data).await
        .with_context(|| format!("無法寫入聲紋檔: {:?}", path))?;
    info!("聲紋已存儲: {:?}", path);
    Ok(())
}

// ─── 餘弦相似度（本地計算，與 Python 服務結果一致）────────────────────────────

fn cosine_similarity(a: &[f32], b: &[f32]) -> f32 {
    debug_assert_eq!(a.len(), b.len(), "嵌入向量維度不一致");
    let dot: f32 = a.iter().zip(b).map(|(x, y)| x * y).sum();
    let norm_a: f32 = a.iter().map(|x| x * x).sum::<f32>().sqrt();
    let norm_b: f32 = b.iter().map(|x| x * x).sum::<f32>().sqrt();
    if norm_a == 0.0 || norm_b == 0.0 { return 0.0; }
    (dot / (norm_a * norm_b)).clamp(-1.0, 1.0)
}

/// 多個樣本嵌入取平均（enrollment 用）
fn mean_embedding(embeddings: &[Vec<f32>]) -> Vec<f32> {
    assert!(!embeddings.is_empty());
    let dim = embeddings[0].len();
    let mut mean = vec![0.0f32; dim];
    for emb in embeddings {
        for (m, &v) in mean.iter_mut().zip(emb.iter()) {
            *m += v;
        }
    }
    let n = embeddings.len() as f32;
    mean.iter_mut().for_each(|v| *v /= n);
    mean
}

// ─── 主要 API ─────────────────────────────────────────────────────────────────

pub struct VoiceprintManager {
    config: VoiceprintConfig,
    client: EcapaClient,
}

impl VoiceprintManager {
    pub fn new(config: VoiceprintConfig) -> Result<Self> {
        let client = EcapaClient::new(&config.endpoint)?;
        Ok(Self { config, client })
    }

    // ─── 登錄流程 ─────────────────────────────────────────────────────────────

    /// 登錄新使用者（需要 N 段語音樣本）
    ///
    /// `audio_chunks`：由外部提供，通常是讓使用者說 N 次固定句子
    pub async fn enroll(
        &self,
        user_id: &str,
        audio_chunks: Vec<AudioChunk>,
    ) -> Result<EnrollmentRecord> {
        info!("開始登錄聲紋: user={} samples={}", user_id, audio_chunks.len());

        if audio_chunks.len() < self.config.enroll_samples as usize {
            return Err(anyhow::anyhow!(
                "樣本不足：需要 {} 段，只有 {} 段",
                self.config.enroll_samples, audio_chunks.len()
            ));
        }

        // 對每段樣本提取嵌入
        let mut embeddings = Vec::new();
        for (i, chunk) in audio_chunks.iter().enumerate() {
            info!("  提取樣本 {}/{}...", i + 1, audio_chunks.len());

            // Liveness check：確認是真實語音
            if self.config.anti_spoof {
                let rms: f32 = {
                    let sum: f32 = chunk.pcm.iter().map(|&s| {
                        let f = s as f32 / i16::MAX as f32;
                        f * f
                    }).sum();
                    (sum / chunk.pcm.len() as f32).sqrt()
                };
                if rms < self.config.liveness_rms {
                    warn!("樣本 {} 能量太低 (rms={:.4})，可能是靜默", i + 1, rms);
                    return Err(anyhow::anyhow!("樣本 {} 偵測到靜默，請重新登錄", i + 1));
                }
            }

            let resp = self.client.embed(chunk).await
                .with_context(|| format!("樣本 {} 嵌入提取失敗", i + 1))?;

            if !resp.is_speech {
                warn!("樣本 {} 未偵測到語音", i + 1);
                return Err(anyhow::anyhow!("樣本 {} 無語音，請對著麥克風說話", i + 1));
            }

            embeddings.push(resp.embedding);
        }

        // 計算平均嵌入作為模板
        let template = mean_embedding(&embeddings);

        // 自我驗證：確認各樣本與模板的相似度都夠高
        let min_self_score = embeddings.iter()
            .map(|e| cosine_similarity(e, &template))
            .fold(f32::MAX, f32::min);

        info!("樣本內部一致性: min_score={:.4}", min_self_score);
        if min_self_score < 0.70 {
            return Err(anyhow::anyhow!(
                "樣本一致性不足（{:.2}），請在安靜環境重新登錄",
                min_self_score
            ));
        }

        let record = EnrollmentRecord {
            user_id: user_id.to_string(),
            enrolled_at: Utc::now(),
            sample_count: audio_chunks.len() as u32,
            embedding_path: enrollment_path(&self.config.store_dir, user_id),
            embedding: template,
        };

        save_enrollment(&record, &self.config.store_dir).await?;
        info!("✅ 聲紋登錄完成: user={}", user_id);
        Ok(record)
    }

    // ─── 驗證流程 ─────────────────────────────────────────────────────────────

    /// 驗證單段語音是否屬於指定使用者
    pub async fn verify_once(&self, user_id: &str, chunk: &AudioChunk) -> Result<VerifyResult> {
        let start = std::time::Instant::now();

        // 載入聲紋模板
        let record = load_enrollment(&self.config.store_dir, user_id)
            .await
            .ok_or_else(|| anyhow::anyhow!("使用者 {} 尚未登錄聲紋", user_id))?;

        // Anti-spoof liveness check
        if self.config.anti_spoof {
            let rms: f32 = {
                let sum: f32 = chunk.pcm.iter().map(|&s| {
                    let f = s as f32 / i16::MAX as f32;
                    f * f
                }).sum();
                (sum / chunk.pcm.len() as f32).sqrt()
            };
            if rms < self.config.liveness_rms {
                warn!("Anti-spoof: 能量太低 (rms={:.4})", rms);
                return Ok(VerifyResult::Spoofing);
            }
        }

        // 送到 ECAPA 服務比對
        let resp = self.client.verify(chunk, &record.embedding).await?;
        let latency_ms = start.elapsed().as_millis() as u64;

        debug!(
            "聲紋比對: user={} score={:.4} threshold={:.4} is_speech={}",
            user_id, resp.score, self.config.threshold, resp.is_speech
        );

        if !resp.is_speech {
            return Ok(VerifyResult::Spoofing);
        }

        if resp.score >= self.config.threshold {
            info!("✅ 聲紋驗證通過: user={} score={:.4}", user_id, resp.score);
            Ok(VerifyResult::Passed { score: resp.score, latency_ms })
        } else {
            warn!("❌ 聲紋驗證失敗: user={} score={:.4} < {:.4}",
                  user_id, resp.score, self.config.threshold);
            Ok(VerifyResult::Rejected { score: resp.score, attempts: 1 })
        }
    }

    /// 是否已登錄
    pub async fn is_enrolled(&self, user_id: &str) -> bool {
        load_enrollment(&self.config.store_dir, user_id).await.is_some()
    }
}

// ─── Challenge-Response 狀態機 ────────────────────────────────────────────────
//
// 狀態轉移：
//
//  Idle
//   │ trigger(operation, detail)
//   ▼
//  Challenging(challenge)
//   │ 收到語音 → verify
//   ├─ Passed  → Approved { operation, args }
//   ├─ Rejected（attempts < max）→ 回到 Challenging（再試）
//   ├─ Rejected（attempts >= max）→ Denied
//   └─ Spoofing → Denied
//

#[derive(Debug, Clone)]
pub enum ChallengeState {
    Idle,
    /// 等待聲紋確認中
    Challenging {
        challenge: VoiceChallenge,
        attempts: u32,
        /// 要放行的操作（給 agent 執行）
        pending_operation: String,
        pending_args: serde_json::Value,
    },
    /// 通過，可執行操作
    Approved {
        operation: String,
        args: serde_json::Value,
        score: f32,
    },
    /// 拒絕
    Denied {
        reason: DenyReason,
        attempts: u32,
    },
}

#[derive(Debug, Clone)]
pub enum DenyReason {
    ScoreTooLow,
    MaxAttemptsReached,
    SpoofingDetected,
}

pub struct ChallengeEngine {
    pub manager: VoiceprintManager,
    pub state: ChallengeState,
    user_id: String,
}

impl ChallengeEngine {
    pub fn new(config: VoiceprintConfig, user_id: String) -> Result<Self> {
        Ok(Self {
            manager: VoiceprintManager::new(config)?,
            state: ChallengeState::Idle,
            user_id,
        })
    }

    /// 觸發一個高風險操作的 challenge
    /// 回傳：要讓 TTS 念出的台語提示文字
    pub async fn trigger(
        &mut self,
        operation: &str,
        detail: &str,
        args: serde_json::Value,
    ) -> Result<String> {
        // 先確認使用者已登錄
        if !self.manager.is_enrolled(&self.user_id).await {
            return Err(anyhow::anyhow!(
                "使用者 {} 尚未登錄聲紋，無法執行高風險操作", self.user_id
            ));
        }

        let challenge = VoiceChallenge::for_operation(operation, detail);
        let prompt = format!(
            "注意！你這馬欲{}。這是高風險的操作，需要聲紋確認。請你說：「{}」",
            challenge.operation, challenge.passphrase
        );

        self.state = ChallengeState::Challenging {
            challenge,
            attempts: 0,
            pending_operation: operation.to_string(),
            pending_args: args,
        };

        Ok(prompt)
    }

    /// 處理使用者的語音回應
    /// 回傳 (狀態描述給 TTS, 是否已通過)
    pub async fn process_response(
        &mut self,
        audio: AudioChunk,
    ) -> Result<(String, bool)> {
        let (challenge, attempts, pending_op, pending_args) = match &self.state {
            ChallengeState::Challenging { challenge, attempts, pending_operation, pending_args } => {
                (challenge.clone(), *attempts, pending_operation.clone(), pending_args.clone())
            }
            _ => return Err(anyhow::anyhow!("目前不在等待聲紋確認的狀態")),
        };

        let result = self.manager.verify_once(&self.user_id, &audio).await?;
        let new_attempts = attempts + 1;

        match result {
            VerifyResult::Passed { score, .. } => {
                self.state = ChallengeState::Approved {
                    operation: pending_op,
                    args: pending_args,
                    score,
                };
                let msg = format!(
                    "聲紋驗證通過（相似度 {:.0}%），正在執行操作...",
                    score * 100.0
                );
                Ok((msg, true))
            }

            VerifyResult::Rejected { score, .. } => {
                if new_attempts >= challenge.max_attempts {
                    self.state = ChallengeState::Denied {
                        reason: DenyReason::MaxAttemptsReached,
                        attempts: new_attempts,
                    };
                    warn!("聲紋驗證達到最大嘗試次數，操作拒絕");
                    let msg = "驗證失敗，次數已到上限，操作已取消，事件已記錄。".to_string();
                    Ok((msg, false))
                } else {
                    let remaining = challenge.max_attempts - new_attempts;
                    self.state = ChallengeState::Challenging {
                        challenge,
                        attempts: new_attempts,
                        pending_operation: pending_op,
                        pending_args,
                    };
                    let msg = format!(
                        "聲紋不符合（相似度 {:.0}%），請閣試一擺，還有 {} 次機會。",
                        score * 100.0, remaining
                    );
                    Ok((msg, false))
                }
            }

            VerifyResult::Spoofing => {
                self.state = ChallengeState::Denied {
                    reason: DenyReason::SpoofingDetected,
                    attempts: new_attempts,
                };
                warn!("⚠️  Anti-spoof 偵測到異常聲音！操作拒絕");
                let msg = "偵測到異常聲音，操作已拒絕，安全事件已記錄。".to_string();
                Ok((msg, false))
            }

            VerifyResult::MaxAttemptsReached => unreachable!(),
        }
    }

    /// 取得目前等待確認的操作（給 agent 執行用）
    pub fn take_approved(&mut self) -> Option<(String, serde_json::Value)> {
        if matches!(&self.state, ChallengeState::Approved { .. }) {
            if let ChallengeState::Approved { operation, args, .. } =
                std::mem::replace(&mut self.state, ChallengeState::Idle)
            {
                return Some((operation, args));
            }
        }
        None
    }

    /// 是否在等待聲紋確認中
    pub fn is_challenging(&self) -> bool {
        matches!(self.state, ChallengeState::Challenging { .. })
    }

    /// 重置到 Idle 狀態
    pub fn reset(&mut self) {
        self.state = ChallengeState::Idle;
    }
}

// ─── 登錄互動流程輔助 ─────────────────────────────────────────────────────────

/// 引導使用者登錄聲紋的台語提示（每個步驟）
pub fn enrollment_prompts(step: u32, total: u32) -> String {
    match step {
        0 => format!(
            "歡迎！開始進行聲紋登錄，總共需要說 {} 遍。\
             請在安靜的環境，對著麥克風清楚地說話。\
             第一遍，請說：「我是 IronClaw 的管理者，允准我操作系統。」",
            total
        ),
        n if n < total => format!(
            "很好！第 {} 遍完成。請再說一遍：\
             「我是 IronClaw 的管理者，允准我操作系統。」",
            n
        ),
        _ => "所有樣本錄製完成，正在建立你的聲紋模板...".to_string(),
    }
}

/// 登錄用的固定口令（台語）
pub const ENROLLMENT_PASSPHRASE: &str = "我是 IronClaw 的管理者，允准我操作系統。";
