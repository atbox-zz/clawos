//! ironclaw-voice — 主程式 (含聲紋驗證整合)
//!
//! 執行模式：
//!   --enroll          聲紋登錄模式
//!   (無參數)          正常語音智能體模式

use anyhow::Result;
use tokio::sync::mpsc;
use tracing::{error, info, warn};

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, serde::Deserialize, Default)]
struct AppConfig {
    #[serde(default)]
    voice_capture: voice_capture::VoiceCaptureConfig,
    #[serde(default)]
    asr: asr_client::AsrConfig,
    #[serde(default)]
    agent: agent_core::AgentConfig,
    #[serde(default)]
    tts: tts_client::TtsConfig,
    #[serde(default)]
    voiceprint: voiceprint::VoiceprintConfig,
    #[serde(default = "default_user_id")]
    user_id: String,
}

fn default_user_id() -> String { "admin".to_string() }

fn load_config() -> Result<AppConfig> {
    let mut cfg: AppConfig = config::Config::builder()
        .add_source(config::File::with_name("config/ironclaw-voice").required(false))
        .add_source(config::Environment::with_prefix("IRONCLAW").separator("_"))
        .build()?
        .try_deserialize()
        .unwrap_or_default();

    if let Ok(key) = std::env::var("QWEN_API_KEY") {
        cfg.tts.api_key = Some(key.clone());
        cfg.agent.api_key = Some(key);
    }
    if let Ok(key) = std::env::var("OPENAI_API_KEY") {
        cfg.asr.openai_api_key = Some(key);
    }
    Ok(cfg)
}

fn print_banner(mode: &str) {
    println!(r#"
  ██╗██████╗  ██████╗ ███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗
  ██║██╔══██╗██╔═══██╗████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║
  ██║██████╔╝██║   ██║██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║
  ██║██╔══██╗██║   ██║██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║
  ██║██║  ██║╚██████╔╝██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝
  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝

  Voice Agent  🎙 台語語音 AI  🛡️ 聲紋驗證  🦀 Rust
  模式: {}
  ─────────────────────────────────────────────────────────────────
"#, mode);
}

// ─── 登錄模式 ─────────────────────────────────────────────────────────────────

async fn run_enrollment(config: AppConfig) -> Result<()> {
    print_banner("聲紋登錄");
    info!("開始登錄使用者: {}", config.user_id);

    // 建立各元件
    let (audio_tx, mut audio_rx) = mpsc::channel::<voice_capture::AudioChunk>(4);
    let tts = tts_client::TtsClient::new(config.tts.clone())?;
    let player = tts_client::AudioPlayer::new()?;
    let mut vp_manager = voiceprint::VoiceprintManager::new(config.voiceprint.clone())?;

    // 啟動麥克風
    tokio::spawn({
        let cfg = config.voice_capture.clone();
        async move { voice_capture::run(audio_tx, cfg).await.ok(); }
    });

    let total = config.voiceprint.enroll_samples;
    let mut samples: Vec<voice_capture::AudioChunk> = Vec::new();

    // 逐步收集樣本
    for step in 0..=total {
        let prompt = voiceprint::enrollment_prompts(step, total);
        info!("提示: {}", prompt);

        // TTS 念出提示
        if let Ok(wav) = tts.synthesize(&prompt).await {
            player.play_wav(&wav)?;
        }

        if step == total {
            // 最後一步：建立模板
            break;
        }

        // 等待使用者說話（取一段語音）
        info!("等待語音樣本 {}/{}...", step + 1, total);
        if let Some(chunk) = audio_rx.recv().await {
            info!("  收到 {}ms 語音", chunk.duration_ms);
            samples.push(chunk);
        }

        tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
    }

    // 建立聲紋模板
    match vp_manager.enroll(&config.user_id, samples).await {
        Ok(record) => {
            info!("✅ 登錄成功! 樣本數: {}", record.sample_count);
            let ok_msg = format!(
                "聲紋登錄成功！使用者 {} 已完成登錄，共 {} 個樣本。系統準備好了。",
                config.user_id, record.sample_count
            );
            if let Ok(wav) = tts.synthesize(&ok_msg).await {
                player.play_wav(&wav)?;
            }
        }
        Err(e) => {
            error!("登錄失敗: {:#}", e);
            let err_msg = format!("登錄失敗：{}。請重新執行登錄程序。", e);
            if let Ok(wav) = tts.synthesize(&err_msg).await {
                player.play_wav(&wav)?;
            }
        }
    }

    Ok(())
}

// ─── 正常運行模式（Orchestrator）─────────────────────────────────────────────

async fn run_agent(config: AppConfig) -> Result<()> {
    print_banner("語音智能體");

    // 確認聲紋是否已登錄
    let vp_config = config.voiceprint.clone();
    let user_id = config.user_id.clone();
    {
        let dummy = voiceprint::VoiceprintManager::new(vp_config.clone())?;
        if !dummy.is_enrolled(&user_id).await {
            warn!("⚠️  使用者 {} 尚未登錄聲紋！", user_id);
            warn!("   高風險操作將無法執行。");
            warn!("   請先執行: ironclaw-voice --enroll");
        } else {
            info!("✅ 聲紋已登錄: {}", user_id);
        }
    }

    // ── 管線通道 ──
    //
    //  mic ──[AudioChunk]──► orchestrator
    //                              │
    //                    ┌─────────┴──────────┐
    //                    │                    │
    //               [正常模式]          [Challenge 模式]
    //                    │                    │
    //                  ASR                 直接比對聲紋
    //                    │                    │
    //                  Agent               判斷通過/拒絕
    //                    │                    │
    //                  TTS ◄────────────────┘

    let (audio_tx, audio_rx) = mpsc::channel::<voice_capture::AudioChunk>(8);
    let (tts_tx,  tts_rx)    = mpsc::channel::<String>(8);

    // 啟動麥克風捕捉
    tokio::spawn({
        let cfg = config.voice_capture.clone();
        async move {
            if let Err(e) = voice_capture::run(audio_tx, cfg).await {
                error!("voice-capture 崩潰: {:#}", e);
            }
        }
    });

    // 啟動 TTS 播放
    tokio::spawn({
        let cfg = config.tts.clone();
        async move {
            if let Err(e) = tts_client::run(tts_rx, cfg).await {
                error!("tts-client 崩潰: {:#}", e);
            }
        }
    });

    info!("✅ 各服務已啟動，等待台語指令...");

    // ── Orchestrator 主迴圈 ──
    orchestrator_loop(
        audio_rx, tts_tx,
        config.asr, config.agent,
        vp_config, user_id,
    ).await
}

/// 核心 Orchestrator：統一管理正常對話 vs 聲紋 Challenge 兩種狀態
async fn orchestrator_loop(
    mut audio_rx: mpsc::Receiver<voice_capture::AudioChunk>,
    tts_tx: mpsc::Sender<String>,
    asr_cfg: asr_client::AsrConfig,
    agent_cfg: agent_core::AgentConfig,
    vp_cfg: voiceprint::VoiceprintConfig,
    user_id: String,
) -> Result<()> {
    // 建立 ASR 客戶端
    let asr = asr_client::AsrClient::new(asr_cfg)?;

    // 建立 Agent
    let mut agent = agent_core::Agent::new(agent_cfg.clone())?;

    // 建立 Challenge Engine
    let mut challenge = voiceprint::ChallengeEngine::new(vp_cfg, user_id.clone())?;

    // 建立 IronClaw Bridge（用於聲紋通過後直接執行高風險操作）
    let ironclaw = ironclaw_bridge::IronClawClient::new(&agent_cfg.ironclaw_socket);

    while let Some(audio_chunk) = audio_rx.recv().await {
        // ── 狀態分流 ──────────────────────────────────────────────────────────
        if challenge.is_challenging() {
            // 【聲紋 Challenge 狀態】
            // 直接把音訊送到聲紋比對，不走 ASR
            info!("🔒 Challenge 模式：進行聲紋比對...");

            match challenge.process_response(audio_chunk).await {
                Ok((msg, approved)) => {
                    // 播放結果訊息
                    tts_tx.send(msg).await.ok();

                    if approved {
                        // 聲紋通過！取出等待執行的操作
                        if let Some((op, args)) = challenge.take_approved() {
                            info!("✅ 執行已核准的高風險操作: {}", op);
                            execute_high_risk_op(&ironclaw, &op, &args, &tts_tx).await;
                        }
                    }
                    // 若未通過，challenge engine 內部已更新嘗試次數
                    // 次數達到上限時 engine 自動轉為 Denied 狀態（不再是 Challenging）
                }
                Err(e) => {
                    error!("聲紋處理錯誤: {:#}", e);
                    tts_tx.send("聲紋驗證發生錯誤，操作取消。".to_string()).await.ok();
                    challenge.reset();
                }
            }

        } else {
            // 【正常對話狀態】
            // 先 ASR，再送 Agent
            let asr_result = match asr.transcribe(&audio_chunk).await {
                Ok(r) => r,
                Err(e) => {
                    error!("ASR 失敗: {:#}", e);
                    continue;
                }
            };

            let text = match asr_client::postprocess(&asr_result.text) {
                Some(t) => t,
                None => continue,
            };

            info!("👤 使用者: {}", text);

            // Agent 處理
            match agent.chat(&text).await {
                Ok(reply) => {
                    // 檢查 reply 是否包含高風險操作請求
                    // （agent 遇到 requires_voiceprint 時，會在回應中夾帶標記）
                    if let Some(vp_req) = extract_voiceprint_request(&reply) {
                        // 啟動 Challenge 流程
                        info!("🔐 觸發聲紋 Challenge: op={} detail={}", vp_req.operation, vp_req.detail);
                        match challenge.trigger(&vp_req.operation, &vp_req.detail, vp_req.args).await {
                            Ok(challenge_prompt) => {
                                tts_tx.send(challenge_prompt).await.ok();
                            }
                            Err(e) => {
                                let err_msg = format!("無法啟動聲紋驗證：{}。操作取消。", e);
                                tts_tx.send(err_msg).await.ok();
                            }
                        }
                    } else {
                        // 普通回應，直接播放
                        tts_tx.send(reply).await.ok();
                    }
                }
                Err(e) => {
                    error!("Agent 失敗: {:#}", e);
                    tts_tx.send("不好意思，我這馬有問題，請閣試一擺。".to_string()).await.ok();
                }
            }
        }
    }

    Ok(())
}

// ─── 高風險操作請求解析 ───────────────────────────────────────────────────────

struct VpRequest {
    operation: String,
    detail: String,
    args: serde_json::Value,
}

/// 從 Agent 回應中提取聲紋驗證請求
/// Agent 遇到 requires_voiceprint 時，回應中會有特定標記
fn extract_voiceprint_request(reply: &str) -> Option<VpRequest> {
    // Agent 的工具結果含有 "__VP_REQUIRED__" 標記時
    // 格式：__VP_REQUIRED__:{"operation":"lock_system","detail":"...","args":{}}
    if let Some(pos) = reply.find("__VP_REQUIRED__:") {
        let json_str = &reply[pos + 16..];
        // 找到 JSON 結尾
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(json_str) {
            return Some(VpRequest {
                operation: v["operation"].as_str().unwrap_or("unknown").to_string(),
                detail: v["detail"].as_str().unwrap_or("").to_string(),
                args: v["args"].clone(),
            });
        }
    }
    None
}

// ─── 高風險操作執行 ───────────────────────────────────────────────────────────

async fn execute_high_risk_op(
    ironclaw: &ironclaw_bridge::IronClawClient,
    operation: &str,
    args: &serde_json::Value,
    tts_tx: &mpsc::Sender<String>,
) {
    let result = match operation {
        "lock_system" => {
            let reason = args["reason"].as_str().unwrap_or("使用者要求");
            let level  = args["level"].as_str().unwrap_or("soft");
            ironclaw.lock_system(reason, level).await
        }
        _ => Err(anyhow::anyhow!("未知高風險操作: {}", operation)),
    };

    let msg = match result {
        Ok(()) => format!("操作 {} 執行完成，審計日誌已記錄。", operation),
        Err(e) => format!("操作執行失敗：{}。", e),
    };
    tts_tx.send(msg).await.ok();
}

// ─── 主程式入口 ───────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    // 初始化 tracing
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("ironclaw_voice=debug".parse()?)
                .add_directive("voice_capture=info".parse()?)
                .add_directive("asr_client=info".parse()?)
                .add_directive("agent_core=info".parse()?)
                .add_directive("tts_client=info".parse()?)
                .add_directive("voiceprint=debug".parse()?)
                .add_directive("ironclaw_bridge=info".parse()?),
        )
        .with_target(false)
        .compact()
        .init();

    let config = load_config()?;

    // 解析命令列參數
    let args: Vec<String> = std::env::args().collect();
    let enroll_mode = args.iter().any(|a| a == "--enroll");

    if enroll_mode {
        tokio::select! {
            r = run_enrollment(config) => r?,
            _ = tokio::signal::ctrl_c() => info!("中斷登錄"),
        }
    } else {
        tokio::select! {
            r = run_agent(config) => r?,
            _ = tokio::signal::ctrl_c() => info!("收到 Ctrl+C，關閉中..."),
        }
    }

    info!("IronClaw Voice Agent 已關閉");
    Ok(())
}
