//! asr-client — 台語語音辨識客戶端
//!
//! 支援兩種 backend：
//!   1. Local Whisper-TW（FastAPI，預設）
//!   2. OpenAI Whisper API（備援）
//!
//! 輸入：AudioChunk（WAV bytes）
//! 輸出：辨識文字（繁體漢字 + 台羅拼音可選）

use anyhow::{Context, Result};
use base64::{Engine, engine::general_purpose::STANDARD as BASE64};
use tokio::sync::mpsc;
use tracing::{debug, error, info, warn};
use voice_capture::AudioChunk;

// ─── 對外型別 ─────────────────────────────────────────────────────────────────

/// ASR 辨識結果
#[derive(Debug, Clone)]
pub struct AsrResult {
    /// 辨識出的文字（繁體中文 / 台語漢字）
    pub text: String,
    /// 信心分數 0.0 ~ 1.0
    pub confidence: f32,
    /// 偵測到的語言
    pub language: String,
    /// 辨識耗時（ms）
    pub latency_ms: u64,
}

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
pub struct AsrConfig {
    /// 使用哪個 backend
    #[serde(default = "default_backend")]
    pub backend: AsrBackend,

    /// 本地 Whisper-TW 服務端點
    #[serde(default = "default_local_endpoint")]
    pub local_endpoint: String,

    /// OpenAI API Key（備援用）
    pub openai_api_key: Option<String>,

    /// 語言提示（給 Whisper 用）
    #[serde(default = "default_language")]
    pub language: String,

    /// HTTP 逾時（秒）
    #[serde(default = "default_timeout_secs")]
    pub timeout_secs: u64,
}

#[derive(Debug, Clone, serde::Deserialize, Default, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum AsrBackend {
    #[default]
    LocalWhisper,
    OpenAiWhisper,
}

fn default_backend() -> AsrBackend { AsrBackend::LocalWhisper }
fn default_local_endpoint() -> String { "http://127.0.0.1:8765".to_string() }
fn default_language() -> String { "zh".to_string() }
fn default_timeout_secs() -> u64 { 30 }

impl Default for AsrConfig {
    fn default() -> Self {
        Self {
            backend: AsrBackend::LocalWhisper,
            local_endpoint: default_local_endpoint(),
            openai_api_key: None,
            language: default_language(),
            timeout_secs: default_timeout_secs(),
        }
    }
}

// ─── ASR 客戶端 ───────────────────────────────────────────────────────────────

pub struct AsrClient {
    config: AsrConfig,
    http: reqwest::Client,
}

impl AsrClient {
    pub fn new(config: AsrConfig) -> Result<Self> {
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(config.timeout_secs))
            .build()?;
        Ok(Self { config, http })
    }

    /// 送出一段音訊，回傳辨識結果
    pub async fn transcribe(&self, chunk: &AudioChunk) -> Result<AsrResult> {
        let start = std::time::Instant::now();

        let wav_bytes = chunk.to_wav_bytes()
            .context("WAV 編碼失敗")?;

        let result = match self.config.backend {
            AsrBackend::LocalWhisper => self.transcribe_local(&wav_bytes).await,
            AsrBackend::OpenAiWhisper => self.transcribe_openai(&wav_bytes).await,
        }?;

        let latency_ms = start.elapsed().as_millis() as u64;
        info!(
            "ASR [{:?}] ✅ \"{}\" ({:.0}% conf, {}ms)",
            self.config.backend, result.text, result.confidence * 100.0, latency_ms
        );

        Ok(AsrResult { latency_ms, ..result })
    }

    // ─── Local Whisper-TW 服務 ────────────────────────────────────────────────
    // 預期的 API：
    //   POST /transcribe
    //   Content-Type: application/json
    //   Body: { "audio_b64": "...", "language": "zh", "task": "transcribe" }
    //   Response: { "text": "...", "language": "zh", "segments": [...] }

    async fn transcribe_local(&self, wav_bytes: &[u8]) -> Result<AsrResult> {
        let audio_b64 = BASE64.encode(wav_bytes);

        #[derive(serde::Serialize)]
        struct LocalReq<'a> {
            audio_b64: &'a str,
            language: &'a str,
            task: &'a str,
        }

        #[derive(serde::Deserialize)]
        struct LocalResp {
            text: String,
            #[serde(default = "default_confidence")]
            confidence: f32,
            #[serde(default = "default_lang")]
            language: String,
        }

        fn default_confidence() -> f32 { 0.9 }
        fn default_lang() -> String { "zh".to_string() }

        let url = format!("{}/transcribe", self.config.local_endpoint);
        let resp: LocalResp = self.http
            .post(&url)
            .json(&LocalReq {
                audio_b64: &audio_b64,
                language: &self.config.language,
                task: "transcribe",
            })
            .send().await
            .with_context(|| format!("無法連線到本地 ASR: {url}"))?
            .json().await
            .context("ASR 回應解析失敗")?;

        Ok(AsrResult {
            text: resp.text.trim().to_string(),
            confidence: resp.confidence,
            language: resp.language,
            latency_ms: 0,
        })
    }

    // ─── OpenAI Whisper API（備援）────────────────────────────────────────────

    async fn transcribe_openai(&self, wav_bytes: &[u8]) -> Result<AsrResult> {
        let api_key = self.config.openai_api_key.as_deref()
            .context("OpenAI API key 未設定")?;

        // multipart/form-data 上傳
        let part = reqwest::multipart::Part::bytes(wav_bytes.to_vec())
            .file_name("audio.wav")
            .mime_str("audio/wav")?;

        let form = reqwest::multipart::Form::new()
            .text("model", "whisper-1")
            .text("language", self.config.language.clone())
            .text("response_format", "verbose_json")
            .part("file", part);

        #[derive(serde::Deserialize)]
        struct OpenAiResp {
            text: String,
            #[serde(default)]
            language: String,
        }

        let resp: OpenAiResp = self.http
            .post("https://api.openai.com/v1/audio/transcriptions")
            .bearer_auth(api_key)
            .multipart(form)
            .send().await
            .context("OpenAI ASR 請求失敗")?
            .json().await
            .context("OpenAI ASR 回應解析失敗")?;

        Ok(AsrResult {
            text: resp.text.trim().to_string(),
            confidence: 0.9, // OpenAI 不回傳信心分數
            language: resp.language,
            latency_ms: 0,
        })
    }
}

// ─── 後處理 ───────────────────────────────────────────────────────────────────

/// 台語 ASR 後處理：
///   - 過濾純標點、空白
///   - 統一全形/半形
///   - 偵測可能的混碼（台語漢字 + 台羅）
pub fn postprocess(text: &str) -> Option<String> {
    let trimmed = text.trim();
    if trimmed.is_empty() || trimmed.chars().all(|c| !c.is_alphanumeric()) {
        return None;
    }
    // 可在此加入更多台語特化後處理
    Some(trimmed.to_string())
}

// ─── 管線主函式 ───────────────────────────────────────────────────────────────

/// 接收 AudioChunk，辨識後將文字送出
pub async fn run(
    mut rx: mpsc::Receiver<AudioChunk>,
    tx: mpsc::Sender<String>,
    config: AsrConfig,
) -> Result<()> {
    info!("🔤  asr-client 啟動 (backend: {:?})", config.backend);

    let client = AsrClient::new(config)?;

    while let Some(chunk) = rx.recv().await {
        debug!("收到語音 {}ms，開始辨識...", chunk.duration_ms);

        match client.transcribe(&chunk).await {
            Ok(result) => {
                if let Some(text) = postprocess(&result.text) {
                    info!("📝  辨識結果: {}", text);
                    if tx.send(text).await.is_err() {
                        info!("asr-client: 接收端關閉，退出");
                        break;
                    }
                }
            }
            Err(e) => {
                error!("ASR 失敗: {:#}", e);
                // 繼續等下一段語音，不中斷服務
            }
        }
    }

    Ok(())
}

// ─── 本地 Whisper-TW 服務（Python FastAPI）────────────────────────────────────

/// 產生啟動本地 ASR 服務的 shell script
pub fn local_asr_server_script() -> &'static str {
    r#"#!/usr/bin/env python3
# ironclaw-voice/scripts/asr_server.py
# 啟動本地 Whisper-TW ASR 服務

import base64, io, time
from fastapi import FastAPI
from pydantic import BaseModel
import torch
import whisper

app = FastAPI(title="IronClaw ASR Server")

print("⏳ 載入 Whisper 模型...")
MODEL_NAME = "large-v3"          # 或換成 fine-tuned 台語模型路徑
model = whisper.load_model(MODEL_NAME)
print(f"✅ 模型載入完成: {MODEL_NAME}")

class TranscribeReq(BaseModel):
    audio_b64: str
    language: str = "zh"
    task: str = "transcribe"

@app.post("/transcribe")
async def transcribe(req: TranscribeReq):
    start = time.time()
    wav_bytes = base64.b64decode(req.audio_b64)
    
    # 寫入暫存 WAV
    import tempfile, os
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(wav_bytes)
        tmp_path = f.name
    
    try:
        result = model.transcribe(
            tmp_path,
            language=req.language,
            task=req.task,
            fp16=torch.cuda.is_available(),
        )
        latency = (time.time() - start) * 1000
        return {
            "text": result["text"].strip(),
            "language": result.get("language", req.language),
            "confidence": 0.9,
            "latency_ms": latency,
        }
    finally:
        os.unlink(tmp_path)

@app.get("/health")
async def health():
    return {"status": "ok", "model": MODEL_NAME}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8765)
"#
}
