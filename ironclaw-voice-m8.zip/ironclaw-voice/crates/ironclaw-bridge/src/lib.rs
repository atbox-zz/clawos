//! ironclaw-bridge — 與 IronClaw 核心安全架構對接
//!
//! 通訊方式：Unix Domain Socket（IPC）
//! 協定：換行分隔的 JSON（NDJSON）
//!
//! IronClaw 核心端需實作對應的 socket server。
//! 目前提供 mock 實作供開發測試。

use anyhow::{Context, Result};
use audit_log::{AuditEvent, AuditSender};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tracing::{debug, info, warn};

// ─── IronClaw 資料型別 ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemStatus {
    pub healthy: bool,
    pub kernel_module: ModuleStatus,
    pub firewall: FirewallStatus,
    pub recent_events: Vec<SecurityEvent>,
    pub uptime_secs: u64,
    pub threat_level: ThreatLevel,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleStatus {
    pub loaded: bool,
    pub version: String,
    pub hooks_active: Vec<String>,
    pub anomalies: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FirewallStatus {
    pub active: bool,
    pub rules_count: u32,
    pub blocked_today: u64,
    pub allowed_today: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityEvent {
    pub id: String,
    pub level: String,
    pub message: String,
    pub source: String,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ThreatLevel {
    Low,
    Medium,
    High,
    Critical,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FirewallRule {
    pub id: String,
    pub ip: String,
    pub port: u16,
    pub protocol: String,
    pub action: String,
    pub direction: String,
    pub hits: u64,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KernelLog {
    pub level: String,
    pub message: String,
    pub module: String,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScanResult {
    pub scope: String,
    pub status: String,
    pub findings: Vec<String>,
    pub scan_id: String,
    pub duration_ms: u64,
}

// ─── IPC 協定 ─────────────────────────────────────────────────────────────────

#[derive(Debug, Serialize)]
struct IpcRequest {
    id: String,
    method: String,
    params: serde_json::Value,
}

#[derive(Debug, Deserialize)]
struct IpcResponse {
    id: String,
    result: Option<serde_json::Value>,
    error: Option<String>,
}

// ─── IronClaw 客戶端 ──────────────────────────────────────────────────────────

pub struct IronClawClient {
    socket_path: String,
    /// 開發模式：使用 mock 資料
    mock_mode: bool,
    audit: Option<AuditSender>,
}

impl IronClawClient {
    pub fn new(socket_path: &str) -> Self {
        // 如果 socket 不存在，自動使用 mock 模式（開發用）
        let mock_mode = !std::path::Path::new(socket_path).exists();
        if mock_mode {
            warn!("⚠️  IronClaw socket 不存在 ({})，使用 mock 模式", socket_path);
        }
        Self {
            socket_path: socket_path.to_string(),
            mock_mode,
            audit: None,
        }
    }

    /// 設定審計發送器
    pub fn with_audit(mut self, sender: AuditSender) -> Self {
        self.audit = Some(sender);
        self
    }

    fn audit_send(&self, event: AuditEvent) {
        if let Some(a) = &self.audit { a.send(event); }
    }

    /// 取得系統安全狀態
    pub async fn get_system_status(&self) -> Result<SystemStatus> {
        if self.mock_mode {
            return Ok(mock_system_status());
        }
        let resp = self.ipc_call("get_system_status", serde_json::Value::Null).await?;
        Ok(serde_json::from_value(resp)?)
    }

    /// 列出防火牆規則
    pub async fn list_firewall_rules(&self, filter: Option<&str>) -> Result<Vec<FirewallRule>> {
        if self.mock_mode {
            return Ok(mock_firewall_rules(filter));
        }
        let params = serde_json::json!({ "filter": filter });
        let resp = self.ipc_call("list_firewall_rules", params).await?;
        Ok(serde_json::from_value(resp)?)
    }

    /// 新增防火牆規則
    pub async fn add_firewall_rule(
        &self,
        ip: &str,
        port: u16,
        action: &str,
        protocol: &str,
        direction: &str,
    ) -> Result<()> {
        info!("🛡️  新增防火牆規則: {} {} {}:{} ({})", action, direction, ip, port, protocol);
        self.audit_send(AuditEvent::FwRuleAdded {
            ip: ip.to_string(),
            port,
            action: action.to_string(),
            direction: direction.to_string(),
            actor: "system".to_string(),
        });
        if self.mock_mode {
            info!("[mock] 防火牆規則已新增");
            return Ok(());
        }
        let params = serde_json::json!({
            "ip": ip, "port": port, "action": action,
            "protocol": protocol, "direction": direction,
        });
        self.ipc_call("add_firewall_rule", params).await?;
        self.audit("add_firewall_rule", &format!("{} {} {}:{}", action, direction, ip, port)).await?;
        Ok(())
    }

    /// 取得核心日誌
    pub async fn get_kernel_logs(&self, level: &str, last_n: usize) -> Result<Vec<KernelLog>> {
        if self.mock_mode {
            return Ok(mock_kernel_logs(level, last_n));
        }
        let params = serde_json::json!({ "level": level, "last_n": last_n });
        let resp = self.ipc_call("get_kernel_logs", params).await?;
        Ok(serde_json::from_value(resp)?)
    }

    /// 執行安全掃描
    pub async fn run_security_scan(&self, scope: &str) -> Result<ScanResult> {
        info!("🔍 觸發安全掃描: {}", scope);
        if self.mock_mode {
            return Ok(mock_scan_result(scope));
        }
        let params = serde_json::json!({ "scope": scope });
        let resp = self.ipc_call("run_security_scan", params).await?;
        Ok(serde_json::from_value(resp)?)
    }

    /// 鎖定系統（需要上層聲紋驗證通過才呼叫）
    pub async fn lock_system(&self, reason: &str, level: &str) -> Result<()> {
        warn!("🔒 系統鎖定: reason={} level={}", reason, level);
        self.audit_send(AuditEvent::SystemLock {
            reason: reason.to_string(),
            level: level.to_string(),
            actor: "system".to_string(),
        });
        self.audit("lock_system", &format!("reason={} level={}", reason, level)).await?;
        if self.mock_mode {
            info!("[mock] 系統已鎖定");
            return Ok(());
        }
        let params = serde_json::json!({ "reason": reason, "level": level });
        self.ipc_call("lock_system", params).await?;
        Ok(())
    }

    /// 寫入審計日誌
    pub async fn audit(&self, action: &str, detail: &str) -> Result<()> {
        debug!("📋 審計: action={} detail={}", action, detail);
        if self.mock_mode {
            return Ok(());
        }
        let params = serde_json::json!({
            "action": action,
            "detail": detail,
            "timestamp": Utc::now().to_rfc3339(),
        });
        self.ipc_call("audit_log", params).await?;
        Ok(())
    }

    // ─── Unix Socket IPC ──────────────────────────────────────────────────────

    async fn ipc_call(&self, method: &str, params: serde_json::Value) -> Result<serde_json::Value> {
        use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
        use tokio::net::UnixStream;

        let req = IpcRequest {
            id: uuid::Uuid::new_v4().to_string(),
            method: method.to_string(),
            params,
        };
        let req_json = serde_json::to_string(&req)? + "\n";

        let mut stream = UnixStream::connect(&self.socket_path)
            .await
            .with_context(|| format!("無法連線到 IronClaw socket: {}", self.socket_path))?;

        stream.write_all(req_json.as_bytes()).await?;

        let mut reader = BufReader::new(stream);
        let mut resp_json = String::new();
        reader.read_line(&mut resp_json).await?;

        let resp: IpcResponse = serde_json::from_str(&resp_json)
            .context("IronClaw 回應解析失敗")?;

        if let Some(err) = resp.error {
            return Err(anyhow::anyhow!("IronClaw 錯誤: {}", err));
        }

        resp.result.ok_or_else(|| anyhow::anyhow!("IronClaw 回應為空"))
    }
}

// ─── Mock 資料（開發測試用）──────────────────────────────────────────────────

fn mock_system_status() -> SystemStatus {
    SystemStatus {
        healthy: true,
        kernel_module: ModuleStatus {
            loaded: true,
            version: "IronClaw-0.9.0".to_string(),
            hooks_active: vec![
                "syscall_filter".to_string(),
                "network_monitor".to_string(),
                "file_integrity".to_string(),
            ],
            anomalies: 0,
        },
        firewall: FirewallStatus {
            active: true,
            rules_count: 42,
            blocked_today: 1337,
            allowed_today: 98765,
        },
        recent_events: vec![
            SecurityEvent {
                id: "evt-001".to_string(),
                level: "warn".to_string(),
                message: "Port scan detected from 192.168.1.254".to_string(),
                source: "network_monitor".to_string(),
                timestamp: Utc::now(),
            },
        ],
        uptime_secs: 86400 * 7,
        threat_level: ThreatLevel::Low,
        timestamp: Utc::now(),
    }
}

fn mock_firewall_rules(filter: Option<&str>) -> Vec<FirewallRule> {
    let rules = vec![
        FirewallRule {
            id: "rule-001".to_string(),
            ip: "0.0.0.0/0".to_string(),
            port: 22,
            protocol: "tcp".to_string(),
            action: "allow".to_string(),
            direction: "inbound".to_string(),
            hits: 5432,
            created_at: Utc::now(),
        },
        FirewallRule {
            id: "rule-002".to_string(),
            ip: "192.168.1.254".to_string(),
            port: 0,
            protocol: "all".to_string(),
            action: "deny".to_string(),
            direction: "both".to_string(),
            hits: 1337,
            created_at: Utc::now(),
        },
    ];
    match filter {
        Some(f) => rules.into_iter().filter(|r| r.ip.contains(f) || r.port.to_string() == f).collect(),
        None => rules,
    }
}

fn mock_kernel_logs(level: &str, last_n: usize) -> Vec<KernelLog> {
    vec![
        KernelLog {
            level: level.to_string(),
            message: format!("[mock] IronClaw 核心運作正常，最近 {} 筆日誌", last_n),
            module: "core".to_string(),
            timestamp: Utc::now(),
        },
        KernelLog {
            level: "warn".to_string(),
            message: "Port scan detected: 192.168.1.254 → :22".to_string(),
            module: "network_monitor".to_string(),
            timestamp: Utc::now(),
        },
    ]
}

fn mock_scan_result(scope: &str) -> ScanResult {
    ScanResult {
        scope: scope.to_string(),
        status: "clean".to_string(),
        findings: vec!["未發現異常".to_string()],
        scan_id: uuid::Uuid::new_v4().to_string(),
        duration_ms: 1234,
    }
}

// 讓 uuid 在 bridge 可用
mod uuid {
    pub struct Uuid;
    impl Uuid {
        pub fn new_v4() -> UuidValue { UuidValue }
    }
    pub struct UuidValue;
    impl UuidValue {
        pub fn to_string(&self) -> String {
            // 簡易 UUID（實際要用 uuid crate）
            format!("{:x}-{:x}-{:x}-{:x}",
                rand_u32(), rand_u32(), rand_u32(), rand_u32())
        }
    }
    fn rand_u32() -> u32 {
        use std::time::{SystemTime, UNIX_EPOCH};
        (SystemTime::now().duration_since(UNIX_EPOCH).unwrap().subsec_nanos()) ^ 0xDEADBEEF
    }
}

use chrono::Utc;
