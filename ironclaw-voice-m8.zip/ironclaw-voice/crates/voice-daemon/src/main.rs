//! ironclaw-voice — 主程式（含 M8 審計日誌整合）
//!
//! 執行模式：
//!   (無參數)              語音智能體
//!   --enroll              聲紋登錄
//!   --verify-audit        驗證審計日誌完整性
//!   --audit-report        顯示審計摘要

use anyhow::Result;
use tokio::sync::mpsc;
use tracing::{error, info, warn};
use audit_log::{AuditConfig, AuditEvent, AuditLogger};

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, serde::Deserialize, Default)]
struct AppConfig {
    #[serde(default)]
    voice_capture: voice_capture::VoiceCaptureConfig,
    #[serde(default)]
    asr: asr_client::AsrConfig,
    #[serde(default)]
    agent: agent_core::AgentConfig,
    #[serde(default)]
    tts: tts_client::TtsConfig,
    #[serde(default)]
    voiceprint: voiceprint::VoiceprintConfig,
    #[serde(default)]
    audit: AuditConfig,
    #[serde(default = "default_user_id")]
    user_id: String,
}
fn default_user_id() -> String { "admin".to_string() }

fn load_config() -> Result<AppConfig> {
    let mut cfg: AppConfig = config::Config::builder()
        .add_source(config::File::with_name("config/ironclaw-voice").required(false))
        .add_source(config::Environment::with_prefix("IRONCLAW").separator("_"))
        .build()?
        .try_deserialize()
        .unwrap_or_default();

    if let Ok(key) = std::env::var("QWEN_API_KEY") {
        cfg.tts.api_key = Some(key.clone());
        cfg.agent.api_key = Some(key);
    }
    if let Ok(key) = std::env::var("OPENAI_API_KEY") {
        cfg.asr.openai_api_key = Some(key);
    }
    // 從環境變數覆寫 HMAC key（正式環境必須）
    if let Ok(key) = std::env::var("IRONCLAW_HMAC_KEY") {
        cfg.audit.hmac_key_hex = key;
    }
    Ok(cfg)
}

fn print_banner(mode: &str) {
    println!(r#"
  ██╗██████╗  ██████╗ ███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗
  ██║██╔══██╗██╔═══██╗████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║
  ██║██████╔╝██║   ██║██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║
  ██║██╔══██╗██║   ██║██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║
  ██║██║  ██║╚██████╔╝██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝
  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝

  Voice Agent  🎙 台語  🛡️ 聲紋  📋 HMAC審計  🦀 Rust
  模式: {}
  ─────────────────────────────────────────────────────────────────
"#, mode);
}

// ─── 模式：驗證審計日誌 ───────────────────────────────────────────────────────

async fn run_verify_audit(config: AppConfig) -> Result<()> {
    print_banner("審計日誌驗證");
    let log_path = &config.audit.log_path;
    let key = &config.audit.hmac_key_hex;

    info!("驗證日誌: {}", log_path);
    let report = audit_log::verify_log(log_path, key).await?;
    println!("\n{}\n", report);

    // 把驗證結果也寫入日誌（自我審計）
    let logger = AuditLogger::new(config.audit.clone())?;
    if report.ok {
        logger.log(AuditEvent::IntegrityVerifyPass {
            entries_checked: report.total_entries,
            log_path: log_path.clone(),
        }).await?;
    } else {
        logger.log(AuditEvent::IntegrityVerifyFail {
            broken_at_seq: report.broken_at_seq.unwrap_or(0),
            log_path: log_path.clone(),
            reason: report.broken_reason.clone().unwrap_or_default(),
        }).await?;
        std::process::exit(1);
    }
    Ok(())
}

// ─── 模式：審計摘要報告 ───────────────────────────────────────────────────────

async fn run_audit_report(config: AppConfig) -> Result<()> {
    let report = audit_log::summary_report(&config.audit.log_path).await?;
    println!("\n{}\n", report);
    Ok(())
}

// ─── 模式：聲紋登錄 ───────────────────────────────────────────────────────────

async fn run_enrollment(config: AppConfig) -> Result<()> {
    print_banner("聲紋登錄");

    // 初始化審計
    let logger = AuditLogger::new(config.audit.clone())?;
    let audit = logger.start_background();

    let (audio_tx, mut audio_rx) = mpsc::channel::<voice_capture::AudioChunk>(4);
    let tts = tts_client::TtsClient::new(config.tts.clone())?;
    let player = tts_client::AudioPlayer::new()?;
    let vp_config = config.voiceprint.clone();
    let user_id = config.user_id.clone();

    tokio::spawn({
        let cfg = config.voice_capture.clone();
        async move { voice_capture::run(audio_tx, cfg).await.ok(); }
    });

    let mut vp_manager = voiceprint::VoiceprintManager::new(vp_config)?;
    let total = config.voiceprint.enroll_samples;
    let mut samples = Vec::new();

    for step in 0..=total {
        let prompt = voiceprint::enrollment_prompts(step, total);
        if let Ok(wav) = tts.synthesize(&prompt).await { player.play_wav(&wav)?; }
        if step == total { break; }
        if let Some(chunk) = audio_rx.recv().await {
            samples.push(chunk);
        }
        tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
    }

    match vp_manager.enroll(&user_id, samples).await {
        Ok(record) => {
            audit.send(AuditEvent::VpEnrollSuccess {
                user_id: user_id.clone(),
                sample_count: record.sample_count,
            });
            let ok_msg = format!("聲紋登錄成功！使用者 {} 共 {} 個樣本，系統準備好了。",
                user_id, record.sample_count);
            if let Ok(wav) = tts.synthesize(&ok_msg).await { player.play_wav(&wav)?; }
        }
        Err(e) => {
            audit.send(AuditEvent::VpEnrollFail {
                user_id: user_id.clone(),
                reason: e.to_string(),
            });
            error!("登錄失敗: {:#}", e);
            let err_msg = format!("登錄失敗：{}。請重新執行。", e);
            if let Ok(wav) = tts.synthesize(&err_msg).await { player.play_wav(&wav)?; }
        }
    }
    Ok(())
}

// ─── 模式：語音智能體（主要功能）────────────────────────────────────────────

async fn run_agent(config: AppConfig) -> Result<()> {
    print_banner("語音智能體");

    // ── 初始化審計日誌 ─────────────────────────────────────────────────────
    let logger = AuditLogger::new(config.audit.clone())?;
    let audit = logger.start_background();

    // 記錄系統啟動
    audit.send_async(AuditEvent::SystemStart {
        version: env!("CARGO_PKG_VERSION").to_string(),
        pid: std::process::id(),
    }).await;

    info!("📋 審計日誌: {}", config.audit.log_path);

    // ── 確認聲紋 ──────────────────────────────────────────────────────────
    let user_id = config.user_id.clone();
    {
        let dummy = voiceprint::VoiceprintManager::new(config.voiceprint.clone())?;
        if !dummy.is_enrolled(&user_id).await {
            warn!("⚠️  使用者 {} 尚未登錄聲紋！高風險操作將無法執行。", user_id);
            warn!("   請先執行: ironclaw-voice --enroll");
        } else {
            info!("✅ 聲紋已登錄: {}", user_id);
        }
    }

    // ── 建立管線 ───────────────────────────────────────────────────────────
    let (audio_tx, audio_rx) = mpsc::channel::<voice_capture::AudioChunk>(8);
    let (tts_tx,  tts_rx)    = mpsc::channel::<String>(8);

    tokio::spawn({
        let cfg = config.voice_capture.clone();
        async move { if let Err(e) = voice_capture::run(audio_tx, cfg).await { error!("voice-capture: {:#}", e); } }
    });
    tokio::spawn({
        let cfg = config.tts.clone();
        async move { if let Err(e) = tts_client::run(tts_rx, cfg).await { error!("tts-client: {:#}", e); } }
    });

    info!("✅ 服務就緒，請講台語！");

    // ── Orchestrator ──────────────────────────────────────────────────────
    let start_time = std::time::Instant::now();
    let result = orchestrator_loop(
        audio_rx, tts_tx.clone(),
        config.asr, config.agent,
        config.voiceprint, user_id.clone(),
        audit.clone(),
    ).await;

    // 記錄系統關閉
    audit.send_async(AuditEvent::SystemStop {
        uptime_secs: start_time.elapsed().as_secs(),
    }).await;

    result
}

// ─── Orchestrator ─────────────────────────────────────────────────────────────

async fn orchestrator_loop(
    mut audio_rx: mpsc::Receiver<voice_capture::AudioChunk>,
    tts_tx: mpsc::Sender<String>,
    asr_cfg: asr_client::AsrConfig,
    agent_cfg: agent_core::AgentConfig,
    vp_cfg: voiceprint::VoiceprintConfig,
    user_id: String,
    audit: audit_log::AuditSender,
) -> Result<()> {
    let asr = asr_client::AsrClient::new(asr_cfg)?;
    let mut agent = agent_core::Agent::new(agent_cfg.clone())?;

    // ChallengeEngine 帶上審計發送器
    let mut challenge = voiceprint::ChallengeEngine::new(vp_cfg, user_id.clone())?
        .with_audit(audit.clone());

    // IronClaw Bridge 帶上審計發送器
    let ironclaw = ironclaw_bridge::IronClawClient::new(&agent_cfg.ironclaw_socket)
        .with_audit(audit.clone());

    while let Some(audio_chunk) = audio_rx.recv().await {
        if challenge.is_challenging() {
            // ── 聲紋 Challenge 狀態 ────────────────────────────────────────
            info!("🔒 Challenge 模式：進行聲紋比對...");
            match challenge.process_response(audio_chunk).await {
                Ok((msg, approved)) => {
                    tts_tx.send(msg).await.ok();
                    if approved {
                        if let Some((op, args)) = challenge.take_approved() {
                            info!("✅ 執行已核准的高風險操作: {}", op);
                            execute_high_risk_op(&ironclaw, &op, &args, &tts_tx, &audit).await;
                        }
                    }
                }
                Err(e) => {
                    error!("聲紋處理錯誤: {:#}", e);
                    tts_tx.send("聲紋驗證發生錯誤，操作取消。".to_string()).await.ok();
                    challenge.reset();
                }
            }
        } else {
            // ── 正常對話狀態 ───────────────────────────────────────────────
            let asr_result = match asr.transcribe(&audio_chunk).await {
                Ok(r) => r,
                Err(e) => { error!("ASR 失敗: {:#}", e); continue; }
            };
            let text = match asr_client::postprocess(&asr_result.text) {
                Some(t) => t,
                None => continue,
            };
            info!("👤 使用者: {}", text);

            match agent.chat(&text).await {
                Ok(reply) => {
                    if let Some(vp_req) = extract_voiceprint_request(&reply) {
                        match challenge.trigger(&vp_req.operation, &vp_req.detail, vp_req.args).await {
                            Ok(prompt) => { tts_tx.send(prompt).await.ok(); }
                            Err(e) => {
                                let msg = format!("無法啟動聲紋驗證：{}。操作取消。", e);
                                tts_tx.send(msg).await.ok();
                            }
                        }
                    } else {
                        tts_tx.send(reply).await.ok();
                    }
                }
                Err(e) => {
                    error!("Agent 失敗: {:#}", e);
                    tts_tx.send("不好意思，我這馬有問題，請閣試一擺。".to_string()).await.ok();
                }
            }
        }
    }
    Ok(())
}

// ─── 工具函式 ─────────────────────────────────────────────────────────────────

struct VpRequest { operation: String, detail: String, args: serde_json::Value }

fn extract_voiceprint_request(reply: &str) -> Option<VpRequest> {
    if let Some(pos) = reply.find("__VP_REQUIRED__:") {
        let json_str = &reply[pos + 16..];
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(json_str) {
            return Some(VpRequest {
                operation: v["operation"].as_str().unwrap_or("unknown").to_string(),
                detail:    v["detail"].as_str().unwrap_or("").to_string(),
                args:      v["args"].clone(),
            });
        }
    }
    None
}

async fn execute_high_risk_op(
    ironclaw: &ironclaw_bridge::IronClawClient,
    operation: &str,
    args: &serde_json::Value,
    tts_tx: &mpsc::Sender<String>,
    audit: &audit_log::AuditSender,
) {
    let result = match operation {
        "lock_system" => {
            let reason = args["reason"].as_str().unwrap_or("使用者要求");
            let level  = args["level"].as_str().unwrap_or("soft");
            ironclaw.lock_system(reason, level).await
        }
        _ => Err(anyhow::anyhow!("未知高風險操作: {}", operation)),
    };

    let (msg, result_str) = match &result {
        Ok(()) => (
            format!("操作 {} 執行完成，審計日誌已記錄。", operation),
            "success".to_string(),
        ),
        Err(e) => (
            format!("操作執行失敗：{}。", e),
            format!("error: {}", e),
        ),
    };

    // 記錄高風險操作執行結果
    audit.send(AuditEvent::HighRiskExecuted {
        operation: operation.to_string(),
        actor: "admin".to_string(),
        result: result_str,
    });

    tts_tx.send(msg).await.ok();
}

// ─── 主程式入口 ───────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("voice_daemon=debug".parse()?)
                .add_directive("audit_log=info".parse()?)
                .add_directive("voiceprint=info".parse()?)
                .add_directive("ironclaw_bridge=info".parse()?)
                .add_directive("agent_core=info".parse()?)
                .add_directive("asr_client=info".parse()?)
                .add_directive("tts_client=info".parse()?)
                .add_directive("voice_capture=info".parse()?),
        )
        .with_target(false)
        .compact()
        .init();

    let args: Vec<String> = std::env::args().collect();
    let config = load_config()?;

    if args.iter().any(|a| a == "--verify-audit") {
        run_verify_audit(config).await
    } else if args.iter().any(|a| a == "--audit-report") {
        run_audit_report(config).await
    } else if args.iter().any(|a| a == "--enroll") {
        tokio::select! {
            r = run_enrollment(config) => r,
            _ = tokio::signal::ctrl_c() => { info!("中斷登錄"); Ok(()) }
        }
    } else {
        tokio::select! {
            r = run_agent(config) => r,
            _ = tokio::signal::ctrl_c() => { info!("收到停止信號"); Ok(()) }
        }
    }
}
