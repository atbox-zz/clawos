//! audit-log — HMAC 鏈式不可竄改審計日誌
//!
//! 設計原則：
//!   1. Append-Only：只能新增，不能修改或刪除
//!   2. HMAC 鏈式：每筆記錄含前一筆的 HMAC-SHA256 指紋
//!      → 任何竄改都會斷鏈，驗證時立即偵測
//!   3. 序號嚴格遞增：seq 中斷表示有記錄被刪除
//!   4. 原子寫入：先寫暫存再 rename，確保不留半寫記錄
//!   5. 檔案鎖：多進程安全
//!
//! 日誌格式（每行一筆 NDJSON）：
//!   {
//!     "seq":      1,
//!     "ts":       "2026-02-25T10:30:00.123Z",
//!     "level":    "CRITICAL",
//!     "category": "VOICEPRINT",
//!     "action":   "VP_SPOOFING_DETECTED",
//!     "actor":    "admin",
//!     "detail":   { ... },
//!     "prev_hmac": "0000...0000",   ← 創世記錄為 0
//!     "hmac":      "a3f8...c2d1",   ← HMAC-SHA256(本筆內容, secret_key)
//!   }
//!
//! 驗證指令：
//!   ironclaw-voice --verify-audit [log_path]

use anyhow::{Context, Result};
use chrono::{DateTime, Utc};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::Sha256;
use std::path::{Path, PathBuf};
use tokio::sync::{mpsc, Mutex};
use tracing::{debug, error, info, warn};

type HmacSha256 = Hmac<Sha256>;

// ─── 審計事件分類 ─────────────────────────────────────────────────────────────

/// 事件嚴重等級
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum AuditLevel {
    Info,
    Warn,
    Critical,
}

impl std::fmt::Display for AuditLevel {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            AuditLevel::Info     => write!(f, "INFO"),
            AuditLevel::Warn     => write!(f, "WARN"),
            AuditLevel::Critical => write!(f, "CRITICAL"),
        }
    }
}

/// 事件類別（來源系統）
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum AuditCategory {
    System,       // 系統啟動 / 關閉
    Auth,         // 認證相關
    Voiceprint,   // 聲紋驗證
    Firewall,     // 防火牆操作
    Kernel,       // 核心層操作
    Agent,        // LLM Agent 操作
    HighRisk,     // 高風險操作
    Integrity,    // 日誌完整性驗證
}

/// 所有可審計的事件
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "action", content = "detail")]
pub enum AuditEvent {
    // ── 系統 ──
    #[serde(rename = "SYSTEM_START")]
    SystemStart { version: String, pid: u32 },

    #[serde(rename = "SYSTEM_STOP")]
    SystemStop { uptime_secs: u64 },

    // ── 聲紋 ──
    #[serde(rename = "VP_ENROLL_SUCCESS")]
    VpEnrollSuccess { user_id: String, sample_count: u32 },

    #[serde(rename = "VP_ENROLL_FAIL")]
    VpEnrollFail { user_id: String, reason: String },

    #[serde(rename = "VP_VERIFY_PASS")]
    VpVerifyPass { user_id: String, score: f32, operation: String },

    #[serde(rename = "VP_VERIFY_FAIL")]
    VpVerifyFail { user_id: String, score: f32, attempts: u32, operation: String },

    #[serde(rename = "VP_SPOOFING")]
    VpSpoofing { user_id: String, rms: f32, operation: String },

    #[serde(rename = "VP_MAX_ATTEMPTS")]
    VpMaxAttempts { user_id: String, attempts: u32, operation: String },

    // ── 高風險操作 ──
    #[serde(rename = "HIGH_RISK_TRIGGERED")]
    HighRiskTriggered { operation: String, detail: String, actor: String },

    #[serde(rename = "HIGH_RISK_APPROVED")]
    HighRiskApproved { operation: String, actor: String, score: f32 },

    #[serde(rename = "HIGH_RISK_DENIED")]
    HighRiskDenied { operation: String, actor: String, reason: String },

    #[serde(rename = "HIGH_RISK_EXECUTED")]
    HighRiskExecuted { operation: String, actor: String, result: String },

    // ── 防火牆 ──
    #[serde(rename = "FW_RULE_ADDED")]
    FwRuleAdded { ip: String, port: u16, action: String, direction: String, actor: String },

    #[serde(rename = "FW_RULE_DELETED")]
    FwRuleDeleted { rule_id: String, actor: String },

    // ── 系統鎖定 ──
    #[serde(rename = "SYSTEM_LOCK")]
    SystemLock { reason: String, level: String, actor: String },

    // ── 核心 ──
    #[serde(rename = "KERNEL_ANOMALY")]
    KernelAnomaly { module: String, description: String, severity: String },

    // ── 完整性 ──
    #[serde(rename = "INTEGRITY_VERIFY_PASS")]
    IntegrityVerifyPass { entries_checked: u64, log_path: String },

    #[serde(rename = "INTEGRITY_VERIFY_FAIL")]
    IntegrityVerifyFail { broken_at_seq: u64, log_path: String, reason: String },
}

impl AuditEvent {
    /// 事件的預設嚴重等級
    pub fn default_level(&self) -> AuditLevel {
        match self {
            AuditEvent::SystemStart { .. }
            | AuditEvent::SystemStop { .. }
            | AuditEvent::VpEnrollSuccess { .. }
            | AuditEvent::VpVerifyPass { .. }
            | AuditEvent::FwRuleAdded { .. }
            | AuditEvent::FwRuleDeleted { .. }
            | AuditEvent::IntegrityVerifyPass { .. } => AuditLevel::Info,

            AuditEvent::VpEnrollFail { .. }
            | AuditEvent::VpVerifyFail { .. }
            | AuditEvent::HighRiskTriggered { .. }
            | AuditEvent::KernelAnomaly { .. } => AuditLevel::Warn,

            AuditEvent::VpSpoofing { .. }
            | AuditEvent::VpMaxAttempts { .. }
            | AuditEvent::HighRiskDenied { .. }
            | AuditEvent::HighRiskApproved { .. }
            | AuditEvent::HighRiskExecuted { .. }
            | AuditEvent::SystemLock { .. }
            | AuditEvent::IntegrityVerifyFail { .. } => AuditLevel::Critical,
        }
    }

    /// 事件類別
    pub fn category(&self) -> AuditCategory {
        match self {
            AuditEvent::SystemStart { .. } | AuditEvent::SystemStop { .. } => AuditCategory::System,
            AuditEvent::VpEnrollSuccess { .. } | AuditEvent::VpEnrollFail { .. }
            | AuditEvent::VpVerifyPass { .. } | AuditEvent::VpVerifyFail { .. }
            | AuditEvent::VpSpoofing { .. } | AuditEvent::VpMaxAttempts { .. } => AuditCategory::Voiceprint,
            AuditEvent::HighRiskTriggered { .. } | AuditEvent::HighRiskApproved { .. }
            | AuditEvent::HighRiskDenied { .. } | AuditEvent::HighRiskExecuted { .. } => AuditCategory::HighRisk,
            AuditEvent::FwRuleAdded { .. } | AuditEvent::FwRuleDeleted { .. } => AuditCategory::Firewall,
            AuditEvent::SystemLock { .. } => AuditCategory::Kernel,
            AuditEvent::KernelAnomaly { .. } => AuditCategory::Kernel,
            AuditEvent::IntegrityVerifyPass { .. } | AuditEvent::IntegrityVerifyFail { .. } => AuditCategory::Integrity,
        }
    }
}

// ─── 日誌條目（完整記錄格式）─────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogEntry {
    /// 嚴格遞增序號（從 1 開始）
    pub seq: u64,
    /// 記錄時間（UTC）
    pub ts: DateTime<Utc>,
    /// 嚴重等級
    pub level: AuditLevel,
    /// 事件類別
    pub category: AuditCategory,
    /// 事件（含 action tag + detail）
    #[serde(flatten)]
    pub event: AuditEvent,
    /// 主機名稱
    pub host: String,
    /// 前一筆的 HMAC（創世記錄 = 64 個 '0'）
    pub prev_hmac: String,
    /// 本筆的 HMAC-SHA256
    /// = HMAC(seq || ts || level || category || event_json || prev_hmac, secret_key)
    pub hmac: String,
}

impl LogEntry {
    /// 計算本筆 HMAC（不含 hmac 欄位本身）
    fn compute_hmac(
        seq: u64,
        ts: &DateTime<Utc>,
        level: &AuditLevel,
        category: &AuditCategory,
        event: &AuditEvent,
        prev_hmac: &str,
        secret_key: &[u8],
    ) -> String {
        let mut mac = HmacSha256::new_from_slice(secret_key)
            .expect("HMAC key 長度無限制");

        // 嚴格定義要簽名的資料，確保雙方一致
        mac.update(seq.to_le_bytes().as_ref());
        mac.update(ts.to_rfc3339().as_bytes());
        mac.update(serde_json::to_string(level).unwrap_or_default().as_bytes());
        mac.update(serde_json::to_string(category).unwrap_or_default().as_bytes());
        mac.update(serde_json::to_string(event).unwrap_or_default().as_bytes());
        mac.update(prev_hmac.as_bytes());

        hex::encode(mac.finalize().into_bytes())
    }

    pub fn verify(&self, secret_key: &[u8]) -> bool {
        let expected = Self::compute_hmac(
            self.seq, &self.ts, &self.level, &self.category,
            &self.event, &self.prev_hmac, secret_key,
        );
        // 恆時比較，防 timing attack
        constant_time_eq(&expected, &self.hmac)
    }
}

fn constant_time_eq(a: &str, b: &str) -> bool {
    if a.len() != b.len() { return false; }
    a.bytes().zip(b.bytes()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Deserialize)]
pub struct AuditConfig {
    /// 日誌檔路徑
    #[serde(default = "default_log_path")]
    pub log_path: String,
    /// HMAC 金鑰（hex 字串，至少 32 bytes）
    /// 正式環境應從 IronClaw HSM 讀取，這裡允許設定檔設定
    #[serde(default = "default_hmac_key")]
    pub hmac_key_hex: String,
    /// 寫入緩衝（ms），0 = 同步寫入
    #[serde(default)]
    pub flush_interval_ms: u64,
    /// 單檔最大大小（bytes），超過後 rotate
    #[serde(default = "default_max_file_bytes")]
    pub max_file_bytes: u64,
    /// 保留幾份 rotated 檔案
    #[serde(default = "default_keep_rotations")]
    pub keep_rotations: u32,
}

fn default_log_path()       -> String { "/var/log/ironclaw/audit.ndjson".to_string() }
fn default_hmac_key()       -> String { "ironclaw-default-hmac-key-change-in-production-32b".to_string() }
fn default_max_file_bytes() -> u64    { 100 * 1024 * 1024 } // 100MB
fn default_keep_rotations() -> u32    { 10 }

impl Default for AuditConfig {
    fn default() -> Self {
        Self {
            log_path: default_log_path(),
            hmac_key_hex: default_hmac_key(),
            flush_interval_ms: 0,
            max_file_bytes: default_max_file_bytes(),
            keep_rotations: default_keep_rotations(),
        }
    }
}

// ─── AuditLogger — 核心寫入器 ─────────────────────────────────────────────────

struct LoggerInner {
    log_path: PathBuf,
    hmac_key: Vec<u8>,
    /// 目前最新一筆的 HMAC（下一筆的 prev_hmac）
    last_hmac: String,
    /// 目前序號
    seq: u64,
    /// 主機名
    hostname: String,
    max_file_bytes: u64,
    keep_rotations: u32,
}

impl LoggerInner {
    fn new(config: &AuditConfig) -> Result<Self> {
        // 解碼 HMAC key（支援 hex 或直接字串）
        let hmac_key = if config.hmac_key_hex.chars().all(|c| c.is_ascii_hexdigit()) && config.hmac_key_hex.len() >= 32 {
            hex::decode(&config.hmac_key_hex).unwrap_or_else(|_| config.hmac_key_hex.as_bytes().to_vec())
        } else {
            config.hmac_key_hex.as_bytes().to_vec()
        };

        let log_path = PathBuf::from(&config.log_path);

        // 建立目錄
        if let Some(parent) = log_path.parent() {
            std::fs::create_dir_all(parent)
                .with_context(|| format!("無法建立日誌目錄: {:?}", parent))?;
        }

        // 讀取現有日誌，取得最後一筆的 HMAC 和序號
        let (last_hmac, seq) = Self::load_last_state(&log_path, &hmac_key)?;

        let hostname = hostname::get()
            .map(|h| h.to_string_lossy().to_string())
            .unwrap_or_else(|_| "unknown".to_string());

        info!("AuditLogger 初始化: path={:?} seq={} last_hmac={}...",
              log_path, seq, &last_hmac[..8]);

        Ok(Self {
            log_path,
            hmac_key,
            last_hmac,
            seq,
            hostname,
            max_file_bytes: config.max_file_bytes,
            keep_rotations: config.keep_rotations,
        })
    }

    /// 讀取現有日誌，取得最後一筆狀態
    fn load_last_state(path: &Path, key: &[u8]) -> Result<(String, u64)> {
        if !path.exists() {
            return Ok(("0".repeat(64), 0));
        }

        let content = std::fs::read_to_string(path)?;
        let mut last_hmac = "0".repeat(64);
        let mut seq = 0u64;

        for line in content.lines() {
            let line = line.trim();
            if line.is_empty() { continue; }
            if let Ok(entry) = serde_json::from_str::<LogEntry>(line) {
                last_hmac = entry.hmac.clone();
                seq = entry.seq;
            }
        }
        info!("日誌續接: seq={} last_hmac={}...", seq, &last_hmac[..8]);
        Ok((last_hmac, seq))
    }

    /// 寫入一筆事件
    fn write(&mut self, event: AuditEvent) -> Result<()> {
        self.seq += 1;
        let ts = Utc::now();
        let level = event.default_level();
        let category = event.category();

        // 計算 HMAC
        let hmac = LogEntry::compute_hmac(
            self.seq, &ts, &level, &category,
            &event, &self.last_hmac, &self.hmac_key,
        );

        let entry = LogEntry {
            seq: self.seq,
            ts,
            level: level.clone(),
            category,
            event,
            host: self.hostname.clone(),
            prev_hmac: self.last_hmac.clone(),
            hmac: hmac.clone(),
        };

        // 序列化
        let mut line = serde_json::to_string(&entry)?;
        line.push('\n');

        // Rotate 檢查
        if self.log_path.exists() {
            let size = std::fs::metadata(&self.log_path)?.len();
            if size + line.len() as u64 > self.max_file_bytes {
                self.rotate()?;
            }
        }

        // 原子 append（用檔案鎖）
        self.append_locked(line.as_bytes())?;

        // 更新狀態
        self.last_hmac = hmac;

        debug!("audit[{}] {:?} {:?}", self.seq, level, entry.category);
        Ok(())
    }

    /// 帶檔案鎖的 append
    fn append_locked(&self, data: &[u8]) -> Result<()> {
        use std::io::Write;
        use fs4::FileExt;

        let file = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.log_path)
            .with_context(|| format!("無法開啟日誌檔: {:?}", self.log_path))?;

        // 排他鎖（同一時間只有一個進程寫入）
        file.lock_exclusive()
            .context("無法取得日誌檔排他鎖")?;

        let mut file = file;
        file.write_all(data)?;
        file.flush()?;

        // 釋放鎖（FileExt::unlock 或直接 drop）
        file.unlock().ok();
        Ok(())
    }

    /// 日誌 Rotate
    fn rotate(&self) -> Result<()> {
        let ts = Utc::now().format("%Y%m%d_%H%M%S");
        let rotated = self.log_path.with_extension(format!("{}.ndjson", ts));

        std::fs::rename(&self.log_path, &rotated)
            .with_context(|| format!("日誌 rotate 失敗: {:?} → {:?}", self.log_path, rotated))?;

        info!("日誌已 rotate: {:?}", rotated);

        // 清理舊檔案
        if let Some(parent) = self.log_path.parent() {
            let stem = self.log_path.file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("audit");
            let mut old_files: Vec<_> = std::fs::read_dir(parent)?
                .filter_map(|e| e.ok())
                .map(|e| e.path())
                .filter(|p| {
                    p.file_name()
                        .and_then(|n| n.to_str())
                        .map(|n| n.starts_with(stem) && n != "audit.ndjson")
                        .unwrap_or(false)
                })
                .collect();
            old_files.sort();
            while old_files.len() > self.keep_rotations as usize {
                let oldest = old_files.remove(0);
                info!("刪除舊日誌: {:?}", oldest);
                std::fs::remove_file(&oldest).ok();
            }
        }
        Ok(())
    }
}

// hostname 輔助（避免外部 crate 相依）
mod hostname {
    pub fn get() -> Result<std::ffi::OsString, ()> {
        let mut buf = vec![0u8; 256];
        unsafe {
            if libc_gethostname(buf.as_mut_ptr() as *mut i8, buf.len()) == 0 {
                let end = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
                Ok(std::ffi::OsString::from(String::from_utf8_lossy(&buf[..end]).to_string()))
            } else {
                Err(())
            }
        }
    }
    // 直接呼叫 libc gethostname
    extern "C" { fn gethostname(name: *mut i8, len: usize) -> i32; }
    fn libc_gethostname(name: *mut i8, len: usize) -> i32 {
        unsafe { gethostname(name, len) }
    }
}

// ─── AuditLogger 公開介面（帶 Mutex，可 Clone 共享）─────────────────────────

#[derive(Clone)]
pub struct AuditLogger {
    inner: std::sync::Arc<Mutex<LoggerInner>>,
}

impl AuditLogger {
    pub fn new(config: AuditConfig) -> Result<Self> {
        let inner = LoggerInner::new(&config)?;
        Ok(Self {
            inner: std::sync::Arc::new(Mutex::new(inner)),
        })
    }

    /// 寫入審計事件（async）
    pub async fn log(&self, event: AuditEvent) -> Result<()> {
        let level = event.default_level();
        if level >= AuditLevel::Critical {
            warn!("🔴 AUDIT CRITICAL: {:?}", event);
        } else {
            debug!("📋 AUDIT: {:?}", event);
        }
        let mut inner = self.inner.lock().await;
        inner.write(event)
    }

    /// 便利方法：記錄並忽略錯誤（不因日誌失敗中斷主流程）
    pub async fn log_silent(&self, event: AuditEvent) {
        if let Err(e) = self.log(event).await {
            error!("審計日誌寫入失敗: {:#}", e);
        }
    }

    /// 啟動後台寫入器（使用 channel，讓呼叫者不需要 await）
    pub fn start_background(self) -> AuditSender {
        let (tx, mut rx) = mpsc::channel::<AuditEvent>(256);
        tokio::spawn(async move {
            while let Some(event) = rx.recv().await {
                self.log_silent(event).await;
            }
        });
        AuditSender { tx }
    }
}

/// 輕量發送端（可 Clone，無鎖）
#[derive(Clone)]
pub struct AuditSender {
    tx: mpsc::Sender<AuditEvent>,
}

impl AuditSender {
    /// 非阻塞發送（滿了就丟棄，不卡主流程）
    pub fn send(&self, event: AuditEvent) {
        if self.tx.try_send(event).is_err() {
            error!("⚠️  審計佇列已滿，事件遺失！");
        }
    }

    /// 異步發送（背壓等待）
    pub async fn send_async(&self, event: AuditEvent) {
        self.tx.send(event).await.ok();
    }
}

// ─── 日誌驗證器 ───────────────────────────────────────────────────────────────

/// 完整性驗證結果
#[derive(Debug)]
pub struct VerifyReport {
    pub log_path: String,
    pub total_entries: u64,
    pub ok: bool,
    pub broken_at_seq: Option<u64>,
    pub broken_reason: Option<String>,
}

impl std::fmt::Display for VerifyReport {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if self.ok {
            write!(f, "✅ 日誌完整 | 條目: {} | 路徑: {}",
                   self.total_entries, self.log_path)
        } else {
            write!(f, "❌ 日誌損壞！seq={} 原因={} | 路徑: {}",
                   self.broken_at_seq.unwrap_or(0),
                   self.broken_reason.as_deref().unwrap_or("未知"),
                   self.log_path)
        }
    }
}

/// 逐行驗證 HMAC 鏈
pub async fn verify_log(log_path: &str, hmac_key_hex: &str) -> Result<VerifyReport> {
    let hmac_key: Vec<u8> = if hmac_key_hex.chars().all(|c| c.is_ascii_hexdigit()) {
        hex::decode(hmac_key_hex).unwrap_or_else(|_| hmac_key_hex.as_bytes().to_vec())
    } else {
        hmac_key_hex.as_bytes().to_vec()
    };

    let path = PathBuf::from(log_path);
    let content = tokio::fs::read_to_string(&path).await
        .with_context(|| format!("無法讀取日誌檔: {}", log_path))?;

    let mut prev_hmac = "0".repeat(64);
    let mut expected_seq = 1u64;
    let mut count = 0u64;

    for (line_no, line) in content.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() { continue; }

        let entry: LogEntry = serde_json::from_str(line)
            .with_context(|| format!("第 {} 行 JSON 解析失敗", line_no + 1))?;

        // 1. 序號連續性檢查
        if entry.seq != expected_seq {
            return Ok(VerifyReport {
                log_path: log_path.to_string(),
                total_entries: count,
                ok: false,
                broken_at_seq: Some(entry.seq),
                broken_reason: Some(format!(
                    "序號不連續：預期 {} 實際 {}", expected_seq, entry.seq
                )),
            });
        }

        // 2. prev_hmac 鏈接檢查
        if entry.prev_hmac != prev_hmac {
            return Ok(VerifyReport {
                log_path: log_path.to_string(),
                total_entries: count,
                ok: false,
                broken_at_seq: Some(entry.seq),
                broken_reason: Some(format!(
                    "HMAC 鏈斷裂：seq={} prev_hmac 不符", entry.seq
                )),
            });
        }

        // 3. HMAC 簽名驗證
        if !entry.verify(&hmac_key) {
            return Ok(VerifyReport {
                log_path: log_path.to_string(),
                total_entries: count,
                ok: false,
                broken_at_seq: Some(entry.seq),
                broken_reason: Some(format!(
                    "HMAC 驗證失敗：seq={} 記錄可能已被竄改", entry.seq
                )),
            });
        }

        prev_hmac = entry.hmac.clone();
        expected_seq += 1;
        count += 1;
    }

    Ok(VerifyReport {
        log_path: log_path.to_string(),
        total_entries: count,
        ok: true,
        broken_at_seq: None,
        broken_reason: None,
    })
}

// ─── 日誌查詢 ─────────────────────────────────────────────────────────────────

/// 查詢過濾條件
#[derive(Debug, Default)]
pub struct QueryFilter {
    pub min_level: Option<AuditLevel>,
    pub since: Option<DateTime<Utc>>,
    pub until: Option<DateTime<Utc>>,
    pub last_n: Option<usize>,
}

/// 查詢日誌（不驗證 HMAC，純讀取）
pub async fn query_log(log_path: &str, filter: QueryFilter) -> Result<Vec<LogEntry>> {
    let content = tokio::fs::read_to_string(log_path).await?;
    let mut entries: Vec<LogEntry> = content.lines()
        .filter(|l| !l.trim().is_empty())
        .filter_map(|l| serde_json::from_str(l).ok())
        .filter(|e: &LogEntry| {
            if let Some(min) = &filter.min_level { if &e.level < min { return false; } }
            if let Some(since) = &filter.since   { if e.ts < *since  { return false; } }
            if let Some(until) = &filter.until   { if e.ts > *until  { return false; } }
            true
        })
        .collect();

    if let Some(n) = filter.last_n {
        let start = entries.len().saturating_sub(n);
        entries = entries.into_iter().skip(start).collect();
    }

    Ok(entries)
}

// ─── 摘要報告 ─────────────────────────────────────────────────────────────────

pub async fn summary_report(log_path: &str) -> Result<String> {
    let entries = query_log(log_path, QueryFilter::default()).await?;
    let total = entries.len();
    let criticals = entries.iter().filter(|e| e.level == AuditLevel::Critical).count();
    let vp_fails  = entries.iter().filter(|e| matches!(&e.event,
        AuditEvent::VpVerifyFail { .. } | AuditEvent::VpSpoofing { .. })).count();
    let high_risk = entries.iter().filter(|e| matches!(&e.event,
        AuditEvent::HighRiskExecuted { .. })).count();

    let first_ts = entries.first().map(|e| e.ts.to_rfc3339()).unwrap_or_default();
    let last_ts  = entries.last().map(|e| e.ts.to_rfc3339()).unwrap_or_default();

    Ok(format!(
        "═══ IronClaw 審計日誌摘要 ═══\n\
         總條目：{}\n\
         CRITICAL 事件：{}\n\
         聲紋驗證失敗：{}\n\
         高風險操作執行：{}\n\
         起始時間：{}\n\
         最後時間：{}",
        total, criticals, vp_fails, high_risk, first_ts, last_ts
    ))
}
