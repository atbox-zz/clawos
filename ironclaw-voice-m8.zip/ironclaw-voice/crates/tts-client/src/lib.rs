//! tts-client — Qwen3-TTS 台語語音合成
//!
//! 支援：
//!   1. Qwen API（DashScope，雲端，低延遲）
//!   2. 本地 Qwen3-TTS-0.6B 服務（隱私優先）
//!
//! 特色：
//!   - 長文字自動切句，每句合成後立即播放（降低首包延遲）
//!   - 支援多種閩南語音色
//!   - 失敗自動 fallback 到本地服務

use anyhow::{Context, Result};
use base64::{Engine, engine::general_purpose::STANDARD as BASE64};
use rodio::{Decoder, OutputStream, Sink};
use tokio::sync::mpsc;
use tracing::{debug, error, info, warn};

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
pub struct TtsConfig {
    /// 使用哪個 provider
    #[serde(default = "default_provider")]
    pub provider: TtsProvider,

    /// Qwen API Key（DashScope）
    pub api_key: Option<String>,

    /// 本地服務端點
    #[serde(default = "default_local_tts_endpoint")]
    pub local_endpoint: String,

    /// 閩南語聲音 ID
    #[serde(default = "default_voice")]
    pub voice: String,

    /// 語速（0.5 ~ 2.0，預設 1.0）
    #[serde(default = "default_speed")]
    pub speed: f32,

    /// 音訊格式
    #[serde(default = "default_format")]
    pub format: String,
}

#[derive(Debug, Clone, serde::Deserialize, Default, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum TtsProvider {
    #[default]
    QwenApi,
    LocalQwen,
    Silent, // 測試用（不發音）
}

fn default_provider() -> TtsProvider { TtsProvider::QwenApi }
fn default_local_tts_endpoint() -> String { "http://127.0.0.1:8766".to_string() }
fn default_voice() -> String { "zh-minnan-female-1".to_string() }
fn default_speed() -> f32 { 1.0 }
fn default_format() -> String { "wav".to_string() }

impl Default for TtsConfig {
    fn default() -> Self {
        Self {
            provider: TtsProvider::QwenApi,
            api_key: None,
            local_endpoint: default_local_tts_endpoint(),
            voice: default_voice(),
            speed: default_speed(),
            format: default_format(),
        }
    }
}

// ─── 文字切句 ─────────────────────────────────────────────────────────────────

/// 將長文字切成適合 TTS 的短句（降低首包延遲）
fn split_sentences(text: &str) -> Vec<String> {
    let mut sentences = Vec::new();
    let mut current = String::new();
    const MAX_LEN: usize = 80; // 每句最多 80 字

    for ch in text.chars() {
        current.push(ch);
        // 遇到句點就切
        if matches!(ch, '。' | '！' | '？' | '…' | '.' | '!' | '?') {
            let s = current.trim().to_string();
            if !s.is_empty() {
                sentences.push(s);
            }
            current.clear();
        } else if current.chars().count() >= MAX_LEN {
            // 超過長度限制，找最近的逗號切
            if let Some(pos) = current.rfind(['，', ',', '、', '；', ';']) {
                let (head, tail) = current.split_at(pos + pos.len_utf8().min(3));
                sentences.push(head.trim().to_string());
                current = tail.trim().to_string();
            }
        }
    }
    if !current.trim().is_empty() {
        sentences.push(current.trim().to_string());
    }
    sentences
}

// ─── TTS 客戶端 ───────────────────────────────────────────────────────────────

pub struct TtsClient {
    config: TtsConfig,
    http: reqwest::Client,
}

impl TtsClient {
    pub fn new(config: TtsConfig) -> Result<Self> {
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(30))
            .build()?;
        Ok(Self { config, http })
    }

    /// 合成一段文字，回傳 WAV bytes
    pub async fn synthesize(&self, text: &str) -> Result<Vec<u8>> {
        debug!("TTS 合成: {}…", &text[..text.len().min(30)]);

        match self.config.provider {
            TtsProvider::QwenApi => self.synthesize_qwen_api(text).await,
            TtsProvider::LocalQwen => self.synthesize_local(text).await,
            TtsProvider::Silent => Ok(Vec::new()),
        }
    }

    // ─── Qwen API (DashScope) ─────────────────────────────────────────────────
    // 文件：https://help.aliyun.com/zh/dashscope/developer-reference/cosyvoice-api

    async fn synthesize_qwen_api(&self, text: &str) -> Result<Vec<u8>> {
        let api_key = self.config.api_key.as_deref()
            .context("Qwen API key 未設定（請設定 QWEN_API_KEY 環境變數）")?;

        #[derive(serde::Serialize)]
        struct QwenTtsReq<'a> {
            model: &'a str,
            input: QwenInput<'a>,
            parameters: QwenParams<'a>,
        }
        #[derive(serde::Serialize)]
        struct QwenInput<'a> {
            text: &'a str,
        }
        #[derive(serde::Serialize)]
        struct QwenParams<'a> {
            voice: &'a str,
            format: &'a str,
            sample_rate: u32,
            speed: f32,
        }

        #[derive(serde::Deserialize)]
        struct QwenTtsResp {
            output: QwenOutput,
        }
        #[derive(serde::Deserialize)]
        struct QwenOutput {
            audio: String, // base64 encoded
        }

        let resp: QwenTtsResp = self.http
            .post("https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation")
            .header("Authorization", format!("Bearer {}", api_key))
            .json(&QwenTtsReq {
                model: "cosyvoice-v1",
                input: QwenInput { text },
                parameters: QwenParams {
                    voice: &self.config.voice,
                    format: &self.config.format,
                    sample_rate: 22050,
                    speed: self.config.speed,
                },
            })
            .send().await
            .context("Qwen TTS API 請求失敗")?
            .json().await
            .context("Qwen TTS 回應解析失敗")?;

        let audio_bytes = BASE64.decode(&resp.output.audio)
            .context("音訊 base64 解碼失敗")?;

        Ok(audio_bytes)
    }

    // ─── 本地 Qwen3-TTS 服務 ─────────────────────────────────────────────────
    // POST /synthesize { "text": "...", "voice": "...", "speed": 1.0 }
    // Response: audio/wav binary

    async fn synthesize_local(&self, text: &str) -> Result<Vec<u8>> {
        let url = format!("{}/synthesize", self.config.local_endpoint);
        let resp = self.http
            .post(&url)
            .json(&serde_json::json!({
                "text": text,
                "voice": self.config.voice,
                "speed": self.config.speed,
                "format": self.config.format,
            }))
            .send().await
            .with_context(|| format!("無法連線到本地 TTS: {url}"))?
            .bytes().await?;

        Ok(resp.to_vec())
    }
}

// ─── 音訊播放器 ───────────────────────────────────────────────────────────────

pub struct AudioPlayer {
    _stream: OutputStream,
    sink: Sink,
}

impl AudioPlayer {
    pub fn new() -> Result<Self> {
        let (_stream, handle) = OutputStream::try_default()
            .context("無法開啟音訊輸出裝置")?;
        let sink = Sink::try_new(&handle)
            .context("無法建立音訊 Sink")?;
        Ok(Self { _stream, sink })
    }

    /// 播放 WAV bytes（阻塞直到播完）
    pub fn play_wav(&self, wav_bytes: &[u8]) -> Result<()> {
        if wav_bytes.is_empty() {
            return Ok(());
        }
        let cursor = std::io::Cursor::new(wav_bytes.to_vec());
        let source = Decoder::new(cursor)
            .context("WAV 解碼失敗")?;
        self.sink.append(source);
        self.sink.sleep_until_end();
        Ok(())
    }

    /// 停止播放
    pub fn stop(&self) {
        self.sink.clear();
    }
}

// ─── 管線主函式 ───────────────────────────────────────────────────────────────

pub async fn run(
    mut rx: mpsc::Receiver<String>,
    config: TtsConfig,
) -> Result<()> {
    info!("🔊 tts-client 啟動 (provider: {:?}, voice: {})", config.provider, config.voice);

    let client = TtsClient::new(config)?;
    let player = AudioPlayer::new()?;

    while let Some(text) = rx.recv().await {
        info!("🗣  合成: {}", &text[..text.len().min(60)]);

        // 切句後逐句合成播放（降低首包延遲）
        let sentences = split_sentences(&text);
        debug!("切成 {} 句", sentences.len());

        for sentence in &sentences {
            if sentence.is_empty() { continue; }

            match client.synthesize(sentence).await {
                Ok(wav) => {
                    if let Err(e) = player.play_wav(&wav) {
                        error!("播放失敗: {:#}", e);
                    }
                }
                Err(e) => {
                    error!("TTS 合成失敗: {:#}", e);
                    // 繼續下一句，不中斷
                }
            }
        }
    }

    Ok(())
}

// ─── 本地 Qwen3-TTS Python 服務腳本 ──────────────────────────────────────────

pub fn local_tts_server_script() -> &'static str {
    r#"#!/usr/bin/env python3
# ironclaw-voice/scripts/tts_server.py
# 啟動本地 Qwen3-TTS 服務

import io, time, base64
from fastapi import FastAPI
from fastapi.responses import Response
from pydantic import BaseModel

app = FastAPI(title="IronClaw TTS Server")

print("⏳ 載入 Qwen3-TTS 模型...")
# 需要安裝：pip install qwen-tts-inference
# 或使用 transformers 載入 Qwen/Qwen3-TTS-0.6B
try:
    from qwen_tts import QwenTTS
    model = QwenTTS.from_pretrained("Qwen/Qwen3-TTS-0.6B")
    print("✅ Qwen3-TTS-0.6B 載入完成")
except ImportError:
    print("⚠️  使用 pyttsx3 作為 fallback TTS")
    import pyttsx3
    model = None

class SynthReq(BaseModel):
    text: str
    voice: str = "zh-minnan-female-1"
    speed: float = 1.0
    format: str = "wav"

@app.post("/synthesize")
async def synthesize(req: SynthReq):
    start = time.time()
    
    if model:
        audio = model.synthesize(
            req.text,
            voice=req.voice,
            speed=req.speed,
        )
        wav_bytes = audio.to_wav()
    else:
        # pyttsx3 fallback（只有普通話）
        import pyttsx3, tempfile, os
        engine = pyttsx3.init()
        engine.setProperty('rate', int(200 * req.speed))
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            tmp_path = f.name
        engine.save_to_file(req.text, tmp_path)
        engine.runAndWait()
        with open(tmp_path, "rb") as f:
            wav_bytes = f.read()
        os.unlink(tmp_path)
    
    latency = (time.time() - start) * 1000
    print(f"TTS 合成完成 {latency:.0f}ms: {req.text[:40]}...")
    
    return Response(content=wav_bytes, media_type="audio/wav")

@app.get("/health")
async def health():
    return {"status": "ok", "model": "Qwen3-TTS-0.6B"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8766)
"#
}
