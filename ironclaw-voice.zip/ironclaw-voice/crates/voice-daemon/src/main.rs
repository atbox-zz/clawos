//! ironclaw-voice — 主程式
//!
//! 啟動整個台語語音 AI 智能體管線：
//!
//!   麥克風 → VAD → ASR → Qwen3 Agent → TTS → 喇叭

use anyhow::Result;
use tokio::sync::mpsc;
use tracing::{error, info};

// ─── 全域設定 ─────────────────────────────────────────────────────────────────

#[derive(Debug, serde::Deserialize, Default)]
struct AppConfig {
    #[serde(default)]
    voice_capture: voice_capture::VoiceCaptureConfig,
    #[serde(default)]
    asr: asr_client::AsrConfig,
    #[serde(default)]
    agent: agent_core::AgentConfig,
    #[serde(default)]
    tts: tts_client::TtsConfig,
}

fn load_config() -> Result<AppConfig> {
    // 優先順序：環境變數 > 設定檔 > 預設值
    let cfg = config::Config::builder()
        .add_source(config::File::with_name("config/ironclaw-voice").required(false))
        .add_source(config::Environment::with_prefix("IRONCLAW").separator("_"))
        .build()?;

    // 從環境變數注入 API keys
    let mut app_cfg: AppConfig = cfg.try_deserialize().unwrap_or_default();

    if let Ok(key) = std::env::var("QWEN_API_KEY") {
        app_cfg.tts.api_key = Some(key.clone());
        app_cfg.agent.api_key = Some(key);
    }
    if let Ok(key) = std::env::var("OPENAI_API_KEY") {
        app_cfg.asr.openai_api_key = Some(key);
    }

    Ok(app_cfg)
}

// ─── 啟動橫幅 ─────────────────────────────────────────────────────────────────

fn print_banner() {
    println!(r#"
  ██╗██████╗  ██████╗ ███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗
  ██║██╔══██╗██╔═══██╗████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║
  ██║██████╔╝██║   ██║██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║
  ██║██╔══██╗██║   ██║██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║
  ██║██║  ██║╚██████╔╝██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝
  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝
  
  Voice Agent — 台語語音 AI 智能體  🦀 Powered by Rust + Qwen3
  請講台語來操控 IronClaw 安全系統
  ─────────────────────────────────────────────────────────────────
"#);
}

// ─── 主程式 ───────────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> Result<()> {
    // 初始化 tracing logger
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("ironclaw=debug".parse()?)
                .add_directive("voice_capture=info".parse()?)
                .add_directive("asr_client=info".parse()?)
                .add_directive("agent_core=info".parse()?)
                .add_directive("tts_client=info".parse()?)
                .add_directive("ironclaw_bridge=info".parse()?),
        )
        .with_target(false)
        .with_thread_names(false)
        .compact()
        .init();

    print_banner();

    // 載入設定
    let config = load_config()?;
    info!("設定載入完成");
    info!("  ASR backend: {:?}", config.asr.backend);
    info!("  LLM model:   {}", config.agent.model);
    info!("  TTS provider:{:?}, voice: {}", config.tts.provider, config.tts.voice);

    // ─── 建立管線通道 ───────────────────────────────────────────────────────────
    //
    //  voice-capture ──[AudioChunk]──► asr-client ──[String]──► agent-core ──[String]──► tts-client
    //                                                                │
    //                                                        ironclaw-bridge
    //

    let (audio_tx, audio_rx) = mpsc::channel::<voice_capture::AudioChunk>(8);
    let (text_tx,  text_rx)  = mpsc::channel::<String>(8);
    let (reply_tx, reply_rx) = mpsc::channel::<String>(8);

    // ─── 啟動各層 ───────────────────────────────────────────────────────────────

    let capture_handle = tokio::spawn({
        let cfg = config.voice_capture;
        async move {
            if let Err(e) = voice_capture::run(audio_tx, cfg).await {
                error!("voice-capture 崩潰: {:#}", e);
            }
        }
    });

    let asr_handle = tokio::spawn({
        let cfg = config.asr;
        async move {
            if let Err(e) = asr_client::run(audio_rx, text_tx, cfg).await {
                error!("asr-client 崩潰: {:#}", e);
            }
        }
    });

    let agent_handle = tokio::spawn({
        let cfg = config.agent;
        async move {
            if let Err(e) = agent_core::run(text_rx, reply_tx, cfg).await {
                error!("agent-core 崩潰: {:#}", e);
            }
        }
    });

    let tts_handle = tokio::spawn({
        let cfg = config.tts;
        async move {
            if let Err(e) = tts_client::run(reply_rx, cfg).await {
                error!("tts-client 崩潰: {:#}", e);
            }
        }
    });

    info!("✅ 所有服務已啟動，等待台語指令...");
    info!("   按 Ctrl+C 停止");

    // 等待停止信號或任一任務崩潰
    tokio::select! {
        _ = tokio::signal::ctrl_c() => {
            info!("收到 Ctrl+C，正在關閉...");
        }
        _ = capture_handle => { error!("voice-capture 意外退出"); }
        _ = asr_handle     => { error!("asr-client 意外退出"); }
        _ = agent_handle   => { error!("agent-core 意外退出"); }
        _ = tts_handle     => { error!("tts-client 意外退出"); }
    }

    info!("IronClaw Voice Agent 已關閉");
    Ok(())
}
