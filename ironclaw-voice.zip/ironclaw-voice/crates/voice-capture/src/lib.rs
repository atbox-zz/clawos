//! voice-capture — 麥克風捕捉 + 語音活動偵測 (VAD)
//!
//! 管線：
//!   麥克風 PCM → 分幀(30ms) → VAD 判斷 → 端點偵測 → AudioChunk 送出

use anyhow::{Context, Result};
use cpal::{
    traits::{DeviceTrait, HostTrait, StreamTrait},
    SampleFormat, SampleRate, StreamConfig,
};
use std::sync::{Arc, Mutex};
use tokio::sync::mpsc;
use tracing::{debug, info, warn};

// ─── 對外資料型別 ─────────────────────────────────────────────────────────────

/// 一段完整的語音段落（說完靜音後切出）
#[derive(Debug, Clone)]
pub struct AudioChunk {
    /// 16kHz, mono, i16 PCM 原始資料
    pub pcm: Vec<i16>,
    /// 持續時間（ms）
    pub duration_ms: u64,
}

impl AudioChunk {
    /// 轉成 WAV bytes（供 ASR HTTP 上傳用）
    pub fn to_wav_bytes(&self) -> Result<Vec<u8>> {
        let mut buf = std::io::Cursor::new(Vec::new());
        let spec = hound::WavSpec {
            channels: 1,
            sample_rate: 16000,
            bits_per_sample: 16,
            sample_format: hound::SampleFormat::Int,
        };
        let mut writer = hound::WavWriter::new(&mut buf, spec)?;
        for &sample in &self.pcm {
            writer.write_sample(sample)?;
        }
        writer.finalize()?;
        Ok(buf.into_inner())
    }
}

// ─── VAD ─────────────────────────────────────────────────────────────────────

/// 輕量 Energy-based VAD（silero 模型可選）
/// 這是不依賴 ONNX 的純計算版本，作為基準先跑起來
pub struct EnergyVad {
    threshold_rms: f32,   // RMS 能量門檻
    frame_samples: usize, // 30ms @ 16kHz = 480 samples
}

impl EnergyVad {
    pub fn new(threshold_rms: f32) -> Self {
        Self {
            threshold_rms,
            frame_samples: 480, // 30ms @ 16kHz
        }
    }

    /// 回傳 true 表示這幀有語音
    pub fn is_speech(&self, samples: &[f32]) -> bool {
        if samples.is_empty() {
            return false;
        }
        let rms = (samples.iter().map(|x| x * x).sum::<f32>() / samples.len() as f32).sqrt();
        rms > self.threshold_rms
    }
}

// ─── VadEndpoint — 端點偵測（說話 → 靜音 → 切出） ─────────────────────────

struct VadEndpoint {
    vad: EnergyVad,
    /// 說話中的緩衝（i16）
    speech_buf: Vec<i16>,
    /// 連續靜音幀數
    silence_frames: usize,
    /// 說話中標記
    speaking: bool,
    /// 靜音多少幀才切出（預設 800ms / 30ms ≒ 27 幀）
    silence_threshold_frames: usize,
    /// 最短語音長度幀數（過濾誤觸，預設 150ms / 30ms = 5 幀）
    min_speech_frames: usize,
    /// 說話幀累計
    speech_frames: usize,
}

impl VadEndpoint {
    fn new(config: &VoiceCaptureConfig) -> Self {
        let frame_ms = 30;
        Self {
            vad: EnergyVad::new(config.vad_rms_threshold),
            speech_buf: Vec::with_capacity(16000 * 10), // 預分配 10 秒
            silence_frames: 0,
            speaking: false,
            silence_threshold_frames: config.silence_ms / frame_ms,
            min_speech_frames: 150 / frame_ms,
            speech_frames: 0,
        }
    }

    /// 餵入一幀 f32 samples（30ms），回傳完整語音段（若切出）
    fn push_frame(&mut self, frame_f32: &[f32], frame_i16: &[i16]) -> Option<AudioChunk> {
        let speech = self.vad.is_speech(frame_f32);

        if speech {
            self.silence_frames = 0;
            self.speech_frames += 1;
            if !self.speaking {
                self.speaking = true;
                debug!("🎙  語音開始");
            }
            self.speech_buf.extend_from_slice(frame_i16);
        } else {
            if self.speaking {
                self.silence_frames += 1;
                // 說話中遇到短暫靜音，繼續緩衝
                self.speech_buf.extend_from_slice(frame_i16);

                if self.silence_frames >= self.silence_threshold_frames {
                    // 靜音超過門檻 → 切出
                    self.speaking = false;
                    let frames = self.speech_frames;
                    self.speech_frames = 0;
                    self.silence_frames = 0;

                    if frames >= self.min_speech_frames {
                        let pcm = std::mem::take(&mut self.speech_buf);
                        let duration_ms = (pcm.len() as u64 * 1000) / 16000;
                        debug!("✂️  語音切出 {}ms ({} samples)", duration_ms, pcm.len());
                        return Some(AudioChunk { pcm, duration_ms });
                    } else {
                        warn!("語音太短（{}幀），丟棄", frames);
                        self.speech_buf.clear();
                    }
                }
            }
        }
        None
    }
}

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
pub struct VoiceCaptureConfig {
    /// VAD RMS 門檻（0.0 ~ 1.0，預設 0.02）
    #[serde(default = "default_vad_threshold")]
    pub vad_rms_threshold: f32,
    /// 靜音多久切出（ms，預設 800）
    #[serde(default = "default_silence_ms")]
    pub silence_ms: usize,
    /// 指定麥克風裝置名稱（None = 預設）
    pub device_name: Option<String>,
}

fn default_vad_threshold() -> f32 { 0.02 }
fn default_silence_ms() -> usize { 800 }

impl Default for VoiceCaptureConfig {
    fn default() -> Self {
        Self {
            vad_rms_threshold: default_vad_threshold(),
            silence_ms: default_silence_ms(),
            device_name: None,
        }
    }
}

// ─── 主函式 ───────────────────────────────────────────────────────────────────

/// 啟動麥克風捕捉，將切出的語音段送到 tx
pub async fn run(
    tx: mpsc::Sender<AudioChunk>,
    config: VoiceCaptureConfig,
) -> Result<()> {
    info!("🎙  voice-capture 啟動");

    let host = cpal::default_host();

    // 選擇麥克風裝置
    let device = match &config.device_name {
        Some(name) => host
            .input_devices()?
            .find(|d| d.name().map(|n| n.contains(name.as_str())).unwrap_or(false))
            .with_context(|| format!("找不到麥克風裝置: {name}"))?,
        None => host
            .default_input_device()
            .context("找不到預設麥克風")?,
    };

    info!("使用麥克風: {}", device.name().unwrap_or_default());

    // 強制 16kHz mono（ASR 標準格式）
    let stream_config = StreamConfig {
        channels: 1,
        sample_rate: SampleRate(16000),
        buffer_size: cpal::BufferSize::Fixed(480), // 30ms
    };

    // 共享緩衝區（回呼 → 主執行緒）
    let shared_buf: Arc<Mutex<Vec<f32>>> = Arc::new(Mutex::new(Vec::new()));
    let shared_buf_cb = Arc::clone(&shared_buf);

    // cpal 回呼（在音訊執行緒執行，不能 async）
    let stream = device.build_input_stream(
        &stream_config,
        move |data: &[f32], _info: &cpal::InputCallbackInfo| {
            if let Ok(mut buf) = shared_buf_cb.lock() {
                buf.extend_from_slice(data);
            }
        },
        |err| warn!("音訊串流錯誤: {err}"),
        None,
    )?;

    stream.play()?;
    info!("🔴 錄音中... 講台語！");

    // 主迴圈：每 30ms 取一幀處理
    let mut endpoint = VadEndpoint::new(&config);
    let frame_size = 480usize; // 30ms @ 16kHz

    loop {
        // 等 30ms
        tokio::time::sleep(tokio::time::Duration::from_millis(30)).await;

        let frames_f32: Vec<f32> = {
            let mut buf = shared_buf.lock().unwrap();
            if buf.len() < frame_size {
                continue;
            }
            buf.drain(..frame_size).collect()
        };

        // f32 → i16
        let frames_i16: Vec<i16> = frames_f32
            .iter()
            .map(|&s| (s * i16::MAX as f32).clamp(i16::MIN as f32, i16::MAX as f32) as i16)
            .collect();

        // VAD + 端點偵測
        if let Some(chunk) = endpoint.push_frame(&frames_f32, &frames_i16) {
            if tx.send(chunk).await.is_err() {
                info!("voice-capture: 接收端關閉，退出");
                break;
            }
        }
    }

    Ok(())
}
