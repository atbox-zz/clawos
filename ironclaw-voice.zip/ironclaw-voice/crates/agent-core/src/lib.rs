//! agent-core — Qwen3 LLM Agent
//!
//! 功能：
//!   - 接收台語文字
//!   - 呼叫 Qwen3（ollama 或 API）進行意圖解析
//!   - Function calling → 執行 IronClaw 工具
//!   - 回傳台語回應文字

use anyhow::{Context, Result};
use ironclaw_bridge::{IronClawClient, SystemStatus};
use serde_json::{json, Value};
use tokio::sync::mpsc;
use tracing::{debug, error, info, warn};

// ─── 系統提示 ─────────────────────────────────────────────────────────────────

const SYSTEM_PROMPT: &str = r#"你是 IronClaw 的核心智能體，代號「鐵爪」。
IronClaw 是一套從 Linux Kernel 底層打造的完整安全防護系統。

【語言規定】
- 使用者用台語（台灣閩南語）跟你說話
- 你也要用台語回應，使用漢字夾台羅拼音的方式書寫
- 例如：「系統目前是正常的，無問題。」「我已經共防火牆規則加起去矣。」

【你的能力】
1. 查詢系統安全狀態（核心層、防火牆、異常事件）
2. 管理防火牆規則（新增、刪除、查詢）
3. 讀取核心安全日誌
4. 觸發安全掃描
5. 緊急鎖定系統（需要聲紋二次確認）

【安全規定】
- 高風險操作（刪除規則、鎖定系統、修改核心設定）執行前，
  一定要用台語說出操作內容，等使用者確認
- 緊急鎖定系統時，要求使用者說出確認口令
- 所有操作都會記錄在審計日誌

【回應風格】
- 簡潔清楚，不要廢話
- 技術資訊可以夾雜英文術語（IP、Port 等）
- 遇到不明白的台語，可以請使用者再說一遍
"#;

// ─── 設定 ─────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, serde::Deserialize)]
pub struct AgentConfig {
    /// LLM 端點（ollama: http://127.0.0.1:11434/v1）
    #[serde(default = "default_llm_endpoint")]
    pub llm_endpoint: String,

    /// 模型名稱
    #[serde(default = "default_model")]
    pub model: String,

    /// 保留對話輪次
    #[serde(default = "default_history_len")]
    pub history_len: usize,

    /// IronClaw 核心 Socket 路徑
    #[serde(default = "default_ironclaw_socket")]
    pub ironclaw_socket: String,

    /// LLM API Key（ollama 不需要）
    pub api_key: Option<String>,
}

fn default_llm_endpoint() -> String { "http://127.0.0.1:11434/v1".to_string() }
fn default_model() -> String { "qwen3:7b".to_string() }
fn default_history_len() -> usize { 10 }
fn default_ironclaw_socket() -> String { "/run/ironclaw/core.sock".to_string() }

impl Default for AgentConfig {
    fn default() -> Self {
        Self {
            llm_endpoint: default_llm_endpoint(),
            model: default_model(),
            history_len: default_history_len(),
            ironclaw_socket: default_ironclaw_socket(),
            api_key: None,
        }
    }
}

// ─── 工具定義 ─────────────────────────────────────────────────────────────────

fn tools_schema() -> Value {
    json!([
        {
            "type": "function",
            "function": {
                "name": "get_system_status",
                "description": "查詢 IronClaw 系統安全狀態，包含核心模組、防火牆、近期異常事件",
                "parameters": {
                    "type": "object",
                    "properties": {}
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "list_firewall_rules",
                "description": "列出所有防火牆規則",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "filter": {
                            "type": "string",
                            "description": "過濾條件，例如 IP 或 port",
                            "nullable": true
                        }
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "add_firewall_rule",
                "description": "新增防火牆規則（中風險操作，需使用者口頭確認）",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "ip": { "type": "string", "description": "目標 IP 或 CIDR" },
                        "port": { "type": "integer", "description": "目標 Port（0 = 全部）" },
                        "protocol": {
                            "type": "string",
                            "enum": ["tcp", "udp", "icmp", "all"],
                            "default": "tcp"
                        },
                        "action": {
                            "type": "string",
                            "enum": ["allow", "deny", "drop"]
                        },
                        "direction": {
                            "type": "string",
                            "enum": ["inbound", "outbound", "both"],
                            "default": "inbound"
                        }
                    },
                    "required": ["ip", "action"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_kernel_logs",
                "description": "讀取 IronClaw 核心安全日誌",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "level": {
                            "type": "string",
                            "enum": ["info", "warn", "error", "critical"],
                            "default": "warn"
                        },
                        "last_n": {
                            "type": "integer",
                            "description": "最近幾筆，預設 20",
                            "default": 20
                        }
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "run_security_scan",
                "description": "觸發安全掃描",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "scope": {
                            "type": "string",
                            "enum": ["quick", "full", "network", "kernel"],
                            "default": "quick"
                        }
                    }
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "lock_system",
                "description": "緊急鎖定系統（高風險！需要聲紋二次確認才能執行）",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "reason": {
                            "type": "string",
                            "description": "鎖定原因"
                        },
                        "level": {
                            "type": "string",
                            "enum": ["soft", "hard", "kernel_panic"],
                            "default": "soft"
                        }
                    },
                    "required": ["reason"]
                }
            }
        }
    ])
}

// ─── Agent 主體 ───────────────────────────────────────────────────────────────

pub struct Agent {
    config: AgentConfig,
    http: reqwest::Client,
    ironclaw: IronClawClient,
    /// 對話歷史
    history: Vec<Value>,
}

impl Agent {
    pub fn new(config: AgentConfig) -> Result<Self> {
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(60))
            .build()?;
        let ironclaw = IronClawClient::new(&config.ironclaw_socket);
        Ok(Self {
            config,
            http,
            ironclaw,
            history: Vec::new(),
        })
    }

    /// 處理一段使用者文字，回傳台語回應
    pub async fn chat(&mut self, user_text: &str) -> Result<String> {
        info!("👤 使用者: {}", user_text);

        // 加入使用者訊息
        self.history.push(json!({ "role": "user", "content": user_text }));

        // 建構訊息列表
        let mut messages = vec![json!({ "role": "system", "content": SYSTEM_PROMPT })];
        // 加入最近 N 輪歷史
        let history_start = self.history.len().saturating_sub(self.config.history_len * 2);
        messages.extend_from_slice(&self.history[history_start..]);

        // 呼叫 LLM（支援多輪工具呼叫）
        let reply = self.llm_loop(messages).await?;

        info!("🤖 鐵爪: {}", reply);
        self.history.push(json!({ "role": "assistant", "content": &reply }));

        Ok(reply)
    }

    /// LLM 推理迴圈（處理 function calling）
    async fn llm_loop(&self, mut messages: Vec<Value>) -> Result<String> {
        const MAX_TOOL_ROUNDS: usize = 5;

        for round in 0..MAX_TOOL_ROUNDS {
            let response = self.call_llm(&messages).await?;

            // 檢查是否有工具呼叫
            let tool_calls = response["choices"][0]["message"]["tool_calls"].as_array();

            if let Some(calls) = tool_calls {
                if !calls.is_empty() {
                    debug!("工具呼叫輪次 {}/{}", round + 1, MAX_TOOL_ROUNDS);

                    // 先把 assistant 的工具呼叫請求加入歷史
                    messages.push(response["choices"][0]["message"].clone());

                    // 逐一執行工具
                    for call in calls {
                        let tool_name = call["function"]["name"].as_str().unwrap_or("");
                        let args_str = call["function"]["arguments"].as_str().unwrap_or("{}");
                        let args: Value = serde_json::from_str(args_str).unwrap_or_default();
                        let call_id = call["id"].as_str().unwrap_or("").to_string();

                        info!("🔧 執行工具: {} {:?}", tool_name, args);
                        let tool_result = self.execute_tool(tool_name, &args).await;

                        let result_str = match tool_result {
                            Ok(v) => serde_json::to_string_pretty(&v)?,
                            Err(e) => format!("{{\"error\": \"{}\"}}", e),
                        };

                        // 工具結果送回
                        messages.push(json!({
                            "role": "tool",
                            "tool_call_id": call_id,
                            "content": result_str,
                        }));
                    }

                    continue; // 再次呼叫 LLM 產生回應
                }
            }

            // 沒有工具呼叫，取出文字回應
            let text = response["choices"][0]["message"]["content"]
                .as_str()
                .unwrap_or("（無回應）")
                .to_string();

            return Ok(text);
        }

        Err(anyhow::anyhow!("工具呼叫超過最大輪次"))
    }

    /// 呼叫 LLM API
    async fn call_llm(&self, messages: &[Value]) -> Result<Value> {
        let url = format!("{}/chat/completions", self.config.llm_endpoint);

        let mut req = self.http.post(&url);
        if let Some(key) = &self.config.api_key {
            req = req.bearer_auth(key);
        }

        let body = json!({
            "model": self.config.model,
            "messages": messages,
            "tools": tools_schema(),
            "tool_choice": "auto",
            "temperature": 0.7,
            "max_tokens": 1024,
        });

        let response: Value = req
            .json(&body)
            .send().await
            .with_context(|| format!("無法連線到 LLM: {url}"))?
            .json().await
            .context("LLM 回應解析失敗")?;

        if let Some(err) = response.get("error") {
            return Err(anyhow::anyhow!("LLM 錯誤: {}", err));
        }

        Ok(response)
    }

    /// 執行工具，回傳結果 JSON
    async fn execute_tool(&self, name: &str, args: &Value) -> Result<Value> {
        match name {
            "get_system_status" => {
                let status = self.ironclaw.get_system_status().await?;
                Ok(serde_json::to_value(status)?)
            }
            "list_firewall_rules" => {
                let filter = args["filter"].as_str();
                let rules = self.ironclaw.list_firewall_rules(filter).await?;
                Ok(serde_json::to_value(rules)?)
            }
            "add_firewall_rule" => {
                let ip = args["ip"].as_str().context("缺少 ip 參數")?;
                let port = args["port"].as_u64().unwrap_or(0) as u16;
                let action = args["action"].as_str().unwrap_or("deny");
                let protocol = args["protocol"].as_str().unwrap_or("tcp");
                let direction = args["direction"].as_str().unwrap_or("inbound");

                self.ironclaw.add_firewall_rule(ip, port, action, protocol, direction).await?;
                Ok(json!({ "success": true, "message": format!("規則已新增: {} {} {}:{}", action, direction, ip, port) }))
            }
            "get_kernel_logs" => {
                let level = args["level"].as_str().unwrap_or("warn");
                let last_n = args["last_n"].as_u64().unwrap_or(20) as usize;
                let logs = self.ironclaw.get_kernel_logs(level, last_n).await?;
                Ok(serde_json::to_value(logs)?)
            }
            "run_security_scan" => {
                let scope = args["scope"].as_str().unwrap_or("quick");
                let result = self.ironclaw.run_security_scan(scope).await?;
                Ok(serde_json::to_value(result)?)
            }
            "lock_system" => {
                // 高風險：這裡先回傳「需要聲紋確認」，由上層處理
                let reason = args["reason"].as_str().unwrap_or("未知原因");
                let level = args["level"].as_str().unwrap_or("soft");
                warn!("⚠️  高風險操作請求: lock_system reason={} level={}", reason, level);
                Ok(json!({
                    "requires_voiceprint": true,
                    "action": "lock_system",
                    "reason": reason,
                    "level": level,
                    "message": "此操作需要聲紋二次確認"
                }))
            }
            _ => Err(anyhow::anyhow!("未知工具: {}", name)),
        }
    }
}

// ─── 管線主函式 ───────────────────────────────────────────────────────────────

pub async fn run(
    mut rx: mpsc::Receiver<String>,
    tx: mpsc::Sender<String>,
    config: AgentConfig,
) -> Result<()> {
    info!("🤖 agent-core 啟動 (model: {})", config.model);

    let mut agent = Agent::new(config)?;

    while let Some(user_text) = rx.recv().await {
        match agent.chat(&user_text).await {
            Ok(reply) => {
                if tx.send(reply).await.is_err() {
                    info!("agent-core: 接收端關閉，退出");
                    break;
                }
            }
            Err(e) => {
                error!("Agent 處理失敗: {:#}", e);
                // 回傳台語錯誤訊息
                let err_msg = "不好意思，我這馬有遇著問題，請你閣試一擺。".to_string();
                let _ = tx.send(err_msg).await;
            }
        }
    }

    Ok(())
}
