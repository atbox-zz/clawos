#!/usr/bin/env bash
# ironclaw-voice/scripts/setup.sh
# 一鍵安裝所有相依環境

set -e
BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[setup]${NC} $1"; }
warn() { echo -e "${YELLOW}[warn]${NC} $1"; }

log "=== IronClaw Voice Agent 環境安裝 ==="

# ─── 1. 系統套件 ──────────────────────────────────────────────────────────────
log "安裝系統套件..."
if command -v apt-get &>/dev/null; then
    sudo apt-get update -q
    sudo apt-get install -y \
        libasound2-dev \
        libpulse-dev \
        pkg-config \
        build-essential \
        python3-pip \
        python3-venv \
        ffmpeg
elif command -v pacman &>/dev/null; then
    sudo pacman -S --needed alsa-lib pulseaudio base-devel python python-pip ffmpeg
fi

# ─── 2. Rust 工具鏈 ───────────────────────────────────────────────────────────
if ! command -v cargo &>/dev/null; then
    log "安裝 Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
fi
log "Rust 版本: $(rustc --version)"

# ─── 3. ollama + Qwen3 ────────────────────────────────────────────────────────
if ! command -v ollama &>/dev/null; then
    log "安裝 ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
fi
log "下載 Qwen3:7b 模型（約 4.7GB）..."
ollama pull qwen3:7b || warn "ollama pull 失敗，請手動執行: ollama pull qwen3:7b"

# ─── 4. Python 環境（ASR + TTS 服務）─────────────────────────────────────────
log "建立 Python 虛擬環境..."
python3 -m venv .venv
source .venv/bin/activate

pip install --upgrade pip -q
pip install -q \
    fastapi \
    uvicorn \
    openai-whisper \
    torch \
    pydantic \
    python-multipart

log "Python 套件安裝完成"

# ─── 5. 產生腳本 ──────────────────────────────────────────────────────────────
cat > scripts/asr_server.py << 'PYEOF'
# 由 Rust 程式碼產生，詳見 asr_client::local_asr_server_script()
import base64, io, time, tempfile, os
from fastapi import FastAPI
from pydantic import BaseModel
import torch, whisper

app = FastAPI(title="IronClaw ASR Server")
MODEL_NAME = "large-v3"
print(f"⏳ 載入 Whisper {MODEL_NAME}...")
model = whisper.load_model(MODEL_NAME)
print(f"✅ Whisper {MODEL_NAME} 載入完成")

class TranscribeReq(BaseModel):
    audio_b64: str
    language: str = "zh"
    task: str = "transcribe"

@app.post("/transcribe")
async def transcribe(req: TranscribeReq):
    wav = base64.b64decode(req.audio_b64)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(wav)
        tmp = f.name
    try:
        result = model.transcribe(tmp, language=req.language, task=req.task,
                                  fp16=torch.cuda.is_available())
        return {"text": result["text"].strip(),
                "language": result.get("language", req.language),
                "confidence": 0.9}
    finally:
        os.unlink(tmp)

@app.get("/health")
def health(): return {"status": "ok", "model": MODEL_NAME}

if __name__ == "__main__":
    import uvicorn; uvicorn.run(app, host="127.0.0.1", port=8765)
PYEOF

# ─── 6. systemd 服務（選用）──────────────────────────────────────────────────
WORK_DIR="$(pwd)"
cat > /tmp/ironclaw-asr.service << EOF
[Unit]
Description=IronClaw ASR Server (Whisper-TW)
After=network.target

[Service]
Type=simple
WorkingDirectory=${WORK_DIR}
ExecStart=${WORK_DIR}/.venv/bin/python ${WORK_DIR}/scripts/asr_server.py
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

cat > /tmp/ironclaw-voice.service << EOF
[Unit]
Description=IronClaw Voice Agent
After=network.target ironclaw-asr.service

[Service]
Type=simple
WorkingDirectory=${WORK_DIR}
ExecStart=${WORK_DIR}/target/release/ironclaw-voice
Restart=on-failure
RestartSec=5
Environment=RUST_LOG=info
EnvironmentFile=-${WORK_DIR}/.env

[Install]
WantedBy=multi-user.target
EOF

log "服務檔已產生到 /tmp（選用安裝）:"
log "  sudo cp /tmp/ironclaw-asr.service /etc/systemd/system/"
log "  sudo cp /tmp/ironclaw-voice.service /etc/systemd/system/"
log "  sudo systemctl enable --now ironclaw-asr ironclaw-voice"

# ─── 7. .env 範本 ─────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
    cat > .env << 'EOF'
# IronClaw Voice Agent 環境變數
# 複製這個檔案並填入你的 API Keys

# Qwen API Key（TTS + LLM）
QWEN_API_KEY=sk-xxxxxxxxxxxxxxxx

# OpenAI API Key（備援 ASR，可不填）
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxx

# 日誌等級
RUST_LOG=ironclaw=debug,info
EOF
    log ".env 範本已建立，請填入你的 API Keys"
fi

# ─── 8. 編譯 ─────────────────────────────────────────────────────────────────
log "編譯 ironclaw-voice..."
cargo build --release 2>&1 | tail -5 || warn "編譯失敗，請檢查錯誤訊息"

echo ""
echo -e "${BOLD}=== 安裝完成！===${NC}"
echo ""
echo "  啟動 ASR 服務："
echo "    source .venv/bin/activate"
echo "    python scripts/asr_server.py &"
echo ""
echo "  啟動 ollama："
echo "    ollama serve &"
echo ""
echo "  啟動 Voice Agent："
echo "    source .env && ./target/release/ironclaw-voice"
echo ""
